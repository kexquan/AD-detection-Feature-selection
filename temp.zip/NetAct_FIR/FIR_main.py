import numpy as np
import os
import torch
from src.FeatureSelector import FeatureSelector
from DataGenerator import generate_data, get_one_hot

def load_sythetic_data(num_trn_samples, num_tst_samples, datatype):
    def generate_data(n=100, datatype='', seed=0):
        """
        Generate data (X,y)
        Args:
            n(int): number of samples
            datatype(string): The type of data
            choices: 'orange_skin', 'XOR', 'regression'.
            seed: random seed used
        Return:
            X(float): [n,d].
            y(float): n dimensional array.
        """
        np.random.seed(seed)

        if datatype == 'binary_classification':
            X = []

            i = 0
            while i < n // 2:
                x = np.random.randn(10)
                if 9 < sum(x[:4] ** 2) < 16:
                    X.append(x)
                    i += 1
            X = np.array(X)

            X = np.concatenate((X, np.random.randn(n // 2, 10)))

            y = np.concatenate((-np.ones(n // 2), np.ones(n // 2)))

            perm_inds = np.random.permutation(n)
            X, y = X[perm_inds], y[perm_inds]

        elif datatype == 'XOR':
            X = np.random.randn(n, 10)
            y = np.zeros(n)
            splits = np.linspace(0, n, num=8 + 1, dtype=int)
            signals = [[1, 1, 1], [-1, -1, -1], [1, 1, -1], [-1, -1, 1], [1, -1, -1], [-1, 1, 1], [-1, 1, -1],
                       [1, -1, 1]]
            for i in range(8):
                X[splits[i]:splits[i + 1], :3] += np.array([signals[i]])
                y[splits[i]:splits[i + 1]] = i // 2

            perm_inds = np.random.permutation(n)
            X, y = X[perm_inds], y[perm_inds]

        return (X, y)

    trn_feats, trn_labels = generate_data(n=num_trn_samples, datatype=datatype, seed=1234)
    tst_feats, tst_labels = generate_data(n=num_tst_samples, datatype=datatype, seed=4321)

    trn_labels[np.where(trn_labels == -1)] = 0
    tst_labels[np.where(tst_labels == -1)] = 0

    return trn_feats, trn_labels, tst_feats, tst_labels


def NetAct_FIR_run(trn_feats, trn_labels, phase_2_start, data_batch_size, mask_batch_size, s, s_p, operator_arch, selector_arch):

    torch.set_default_tensor_type(torch.cuda.DoubleTensor)
    # torch.set_default_tensor_type(torch.DoubleTensor)

    FEATURE_SHAPE = (trn_feats.shape[1],)
    early_stopping_patience = 600  # how many patience batches (after phase 2 starts)
    max_batches = 10000  # how many batches if the early stopping condition not satisfied

    # Create the framework, needs number of features and batch_sizes, str_id for tensorboard
    fs = FeatureSelector(FEATURE_SHAPE, s, data_batch_size, mask_batch_size, str_id='test', epoch_on_which_selector_trained=2)

    # Create a dense operator net, uses the architecture:
    # N_FEATURES x 2 -> 60 -> 30 -> 20 -> 4
    # with sigmoid activation in the final layer.
    fs.create_dense_operator(operator_arch, "softmax")
    # Ealy stopping activate after the phase2 of the training starts.
    fs.operator.set_early_stopping_params(phase_2_start, patience_batches=early_stopping_patience, minimize=True)

    # Create a dense selector net, uses the architecture:
    # N_FEATURES -> 60 -> 30 -> 20 -> 4
    fs.create_dense_selector(selector_arch)

    # Set when the phase2 starts, what is the number of flipped bits when perturbin masks
    fs.create_mask_optimizer(epoch_condition=phase_2_start, perturbation_size=s_p)

    # Train networks and set the maximum number of iterations
    fs.train_networks_on_data(trn_feats, trn_labels, max_batches)

    # Results
    importances = fs.get_importances(return_chosen_features=True)
    # optimal_subset = np.nonzero(optimal_mask)
    # test_performance = fs.operator.test_one(X_te, optimal_mask[None,:], y_te)
    # print("Importances: ", importances)
    # print("Optimal_subset: ", optimal_subset)
    # print("Test performance (CE): ", test_performance[0])
    # print("Test performance (ACC): ", test_performance[1])

    return importances


if __name__ == '__main__':

    os.environ["CUDA_VISIBLE_DEVICES"] = "0"

    # Dataset parameters
    N_TRAIN_SAMPLES = 512
    N_VAL_SAMPLES = 256
    N_TEST_SAMPLES = 1024
    N_FEATURES = 10
    FEATURE_SHAPE = (10,)
    dataset_label = "XOR_"

    # Training parapmeters
    data_batch_size = 32
    mask_batch_size = 32
    # final batch_size is data_batch_size x mask_batch_size
    s = 5  # size of optimal subset that we are looking for
    s_p = 2  # number of flipped bits in a mask when looking around m_opt
    # before the training stops

    # Generate data for XOR dataset:
    # First three features are used to create the target (y)
    # All the following features are gaussian noise
    # In total 10 features
    # X_tr, y_tr = generate_data(n=N_TRAIN_SAMPLES, seed=0)
    # X_val, y_val = generate_data(n=N_VAL_SAMPLES, seed=0)
    # X_te, y_te = generate_data(n=N_TEST_SAMPLES, seed=0)

    X_tr, y_tr, X_te, y_te = load_sythetic_data(N_TRAIN_SAMPLES, N_TEST_SAMPLES, 'binary_classification')
    _, _, X_val, y_val = load_sythetic_data(N_TRAIN_SAMPLES, N_TEST_SAMPLES, 'binary_classification')

    # X_tr = np.concatenate((X_tr, X_tr), axis=1)
    # X_val = np.concatenate((X_val, X_val), axis=1)
    # X_te = np.concatenate((X_te, X_te), axis=1)

    # Get one hot encoding of the labels
    y_tr = get_one_hot(y_tr.astype(np.int8), 2)
    y_te = get_one_hot(y_te.astype(np.int8), 2)
    y_val = get_one_hot(y_val.astype(np.int8), 2)
    # importances = run(X_tr, y_tr, s, s_p, data_batch_size, mask_batch_size)

    phase_2_start = 6000
    operator_arch = [10, 128, 128, 2]
    selector_arch = [10, 128, 128, 1]

    importances, optimal_masks = NetAct_FIR_run(X_tr, y_tr,
                                     phase_2_start,
                                     data_batch_size,
                                     mask_batch_size,
                                     s, s_p,
                                     operator_arch,
                                     selector_arch)

    print(importances)
    print(optimal_masks)

    import matplotlib.pyplot as plt

    plt.plot(range(len(importances)), importances)
    plt.xticks(range(len(importances)))
    plt.grid()
    plt.savefig('temp.jpg')
    plt.show()
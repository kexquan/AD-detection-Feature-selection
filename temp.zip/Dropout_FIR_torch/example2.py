import numpy as np
import os
import tensorflow.keras as keras
from tensorflow.keras import backend as K
from src.FeatureSelector import FeatureSelector
from DataGenerator import generate_data, get_one_hot
import h5py
from sklearn.preprocessing import StandardScaler
import scipy.io as sio
import torch

def run(train_features, train_labels, FEATURE_SHAPE, identifier):

    # Training parapmeters
    data_batch_size = 32
    mask_batch_size = 32
    # final batch_size is data_batch_size x mask_batch_size
    s = 5  # size of optimal subset that we are looking for
    s_p = 2  # number of flipped bits in a mask when looking around m_opt
    phase_2_start = 6000  # after how many batches phase 2 will begin
    max_batches = 25000  # how many batches if the early stopping condition not satisfied
    early_stopping_patience = 600  # how many patience batches (after phase 2 starts)
    # before the training stops

    X_tr = train_features
    y_tr = train_labels
    X_val = X_tr
    y_val = y_tr

    # Get one hot encoding of the labels
    y_tr = get_one_hot(y_tr.astype(np.int8), 2)
    y_val = get_one_hot(y_val.astype(np.int8), 2)

    # Create the framework, needs number of features and batch_sizes, str_id for tensorboard
    fs = FeatureSelector(FEATURE_SHAPE, s, data_batch_size, mask_batch_size,
                         str_id=identifier,
                         epoch_on_which_selector_trained=2)

    fs.create_dense_operator([128, 32, 2], "softmax")

    # Ealy stopping activate after the phase2 of the training starts.
    fs.operator.set_early_stopping_params(phase_2_start, patience_batches=early_stopping_patience, minimize=True)

    # dropout
    init_dropout_rate = 0.35
    fs.create_dense_selector([128, 32, 1], init_dropout_rate)

    # Set when the phase2 starts, what is the number of flipped bits when perturbin masks
    fs.create_mask_optimizer(epoch_condition=phase_2_start, perturbation_size=s_p)

    # Train networks and set the maximum number of iterations
    fs.train_networks_on_data(X_tr, y_tr, max_batches, val_data=(X_val, y_val))

    # droout
    preserve_logit_p = fs.get_dropout_logit_p()

    filename = 'results/ADReSS/' + identifier + '_Dropout_FIR_torch.mat'
    sio.savemat(filename, {'preserve_logit_p': preserve_logit_p})

import os
import pandas as pd
def load_features():

    def find_files(path, ext="", prefix=""):
        return [os.path.join(path, x) for x in os.listdir(path) if x.endswith(ext) and x.startswith(prefix)]

    feature_path = '/home11a/xiaoquan/learning/features/AD2021/train/GeMAPS'
    files = find_files(feature_path, ext='.csv')
    files.sort()
    features_all = []
    for file in files:
        temp = np.array(pd.read_csv(file, sep=';'))
        features_all.append(temp.flatten()[1:])

    features_all = np.array(features_all).astype(np.float)
    trn_feats = features_all
    trn_labels = np.concatenate((1 * np.ones(shape=(78,)), 3 * np.ones(shape=(108,)), 2 * np.ones(shape=(93,))))

    return trn_feats, trn_labels


if __name__ == '__main__':

    os.environ["CUDA_VISIBLE_DEVICES"] = "0"
    torch.set_default_tensor_type(torch.cuda.DoubleTensor)

    seed = 1234
    np.random.seed(seed)
    torch.manual_seed(seed)

    trn_feats, tran_labels = load_features()

    print(tran_features.shape)








import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.model_selection import KFold
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score


class Classifier():
    def __init__(
        self,
        mode='svm',
        pre='pca',
        C=1,
        kernel='rbf',
        n_components=None,
    ):
        self.mode = mode
        self.pre = pre
        self.C = C
        self.kernel = kernel
        self.n_components = n_components

    def fit(self, X, y, shuffle=True):
        if shuffle:
            pid = np.random.permutation(len(y))
            X, y = X[pid], y[pid]
        pipe = []
        if self.pre == 'sc':
            pipe.append(('scaler', StandardScaler()))
            # pipe.append(('scaler', RobustScaler()))
        elif self.pre == 'pca':
            pipe.append(('scaler', StandardScaler()))
            # pipe.append(('scaler', RobustScaler()))
            # pipe.append(('pca', PCA(n_components=self.n_components)))
        elif self.pre == 'robust':
            pipe.append(('scaler', RobustScaler()))

        if self.mode == 'svm':
            pipe.append(('cls', SVC(C=self.C, kernel=self.kernel, probability=True)))
        elif self.mode == 'lda':
            pipe.append(('cls', LDA()))
        self.pipe = Pipeline(pipe)
        self.pipe.fit(X, y)

    def test(self, X, y):
        scores = {'acc': [], 'prec': [], 'rec': [], 'f1': []}
        preds = self.pipe.predict(X)
        # logits = self.pipe.predict_proba(X)
        scores['acc'] = accuracy_score(y, preds)
        scores['prec'] = precision_score(y, preds, average='macro')
        # scores['prec'] = precision_score(y, preds)
        scores['rec'] = recall_score(y, preds, average='macro')
        # scores['rec'] = recall_score(y, preds)
        scores['f1'] = f1_score(y, preds, average='macro')
        # scores['f1'] = f1_score(y, preds)
        return scores

    def cross_validate(self, X, y, cv=5, times=None):
        scores = {}
        times = 1 if times is None else times
        for _ in range(times):
            pid = np.random.permutation(len(y))
            X, y = X[pid], y[pid]
            cv = len(y) if cv == -1 else cv
            kf = KFold(n_splits=cv, shuffle=True)
            for trn_idx, tst_idx in kf.split(X):
                self.fit(X[trn_idx], y[trn_idx])
                tst_scores = self.test(X[tst_idx], y[tst_idx])
                for key, val in tst_scores.items():
                    if key not in scores.keys():
                        scores[key] = []
                    scores[key].append(val)
        for key, val in scores.items():
            scores[key] = np.asarray(val)
        return scores

    def fit_test(self, X_trn, y_trn, X_tst, y_tst, times=25):
        scores = {}
        for _ in range(times):
            self.fit(X_trn, y_trn)
            tst_scores = self.test(X_tst, y_tst)
            for key, val in tst_scores.items():
                if key not in scores.keys():
                    scores[key] = []
                scores[key].append(val)
        for key, val in scores.items():
            scores[key] = np.asarray(val)
        return scores

    def cv_test(self, features, labels, tst_features, test_ad, cv=5, times=5, testtimes=1):
        scores = self.cross_validate(features, labels, cv=cv, times=times)
        print(". \tacc\t      prec\t    rec\t\t  f1")
        print("cv{}:".format(cv), self.scores_str(scores))
        # print("All accs:"+(("\n"+" {:.2f}"*cv)*times).format(*scores['acc']))
        tst_scores = self.fit_test(features, labels, tst_features, test_ad, times=testtimes)
        print("tst:", self.scores_str(tst_scores))
        return scores, tst_scores

    def scores_str(self, scores):
        return "{:.3f} ({:.3f}) & {:.3f} ({:.3f}) & {:.3f} ({:.3f}) & {:.3f} ({:.3f})".format(
            scores['acc'].mean(), scores['acc'].std(), scores['prec'].mean(), scores['prec'].std(),
            scores['rec'].mean(), scores['rec'].std(), scores['f1'].mean(), scores['f1'].std())

    def print_scores(self, scores, mode='test'):
        if mode == 'test':
            print(("{:<6}"*4).format('acc', 'prec', 'rec', 'f1'))
            table = []
            for _, val in scores.items():
                table.append("{:<6}".format("{:.2f}".format(val)))
            print(''.join(table))
        else:
            print(("{:<12}"*4).format('acc', 'prec', 'rec', 'f1'))
            table = []
            for _, val in scores.items():
                table.append("{:<12}".format("{:.2f}({:.2f})".format(val.mean(), val.std())))
            print(''.join(table))

import os
def find_files(path, ext="", prefix=""):
    return [os.path.join(path, x) for x in os.listdir(path) if x.endswith(ext) and x.startswith(prefix)]
import pandas as pd

def load_test_labels(file):
    test_df_true = pd.read_csv(file)  # Read testing set meta data
    test_subject_id2 = test_df_true[test_df_true.columns.values[0]].apply(lambda x: x.split(';')[0]).values
    test_subject_labels = test_df_true[test_df_true.columns.values[0]].apply(
        lambda x: x.split(';')[3]).values.astype(np.int32)
    # make sure test_subject_id2 is in ascending order
    id_index2 = np.argsort(test_subject_id2)
    test_subject_id2 = test_subject_id2[id_index2]
    test_subject_labels = test_subject_labels[id_index2]
    return test_subject_labels



import scipy.io as sio
import pdb

def load_ADReSS_linguistic_features():

    import os
    def find_files(path, ext="", prefix=""):
        return [os.path.join(path, x) for x in os.listdir(path) if x.endswith(ext) and x.startswith(prefix)]

    def load_test_labels(file):
        test_df_true = pd.read_csv(file)  # Read testing set meta data
        test_subject_id2 = test_df_true[test_df_true.columns.values[0]].apply(lambda x: x.split(';')[0]).values
        test_subject_labels = test_df_true[test_df_true.columns.values[0]].apply(
            lambda x: x.split(';')[3]).values.astype(np.int32)
        # make sure test_subject_id2 is in ascending order
        id_index2 = np.argsort(test_subject_id2)
        test_subject_id2 = test_subject_id2[id_index2]
        test_subject_labels = test_subject_labels[id_index2]
        return test_subject_labels

    features_lex = []
    feature_path_lex = '/home11a/xiaoquan/learning/features/ADReSS_features/lexicosyntactic_PAR'
    files_lex = find_files(feature_path_lex, ext='.csv')
    files_lex.sort()
    for file in files_lex:
        temp = np.array(pd.read_csv(file))
        features_lex.append(temp.flatten())
    features_lex = np.array(features_lex).astype(np.float)
    features_lex[np.isinf(features_lex)] = 0
    features_lex[np.isnan(features_lex)] = 0
    features_lex = np.delete(features_lex,  [270,272,274,276], axis=1)

    features_liwc = []
    feature_path_liwc = '/home11a/xiaoquan/learning/features/ADReSS_features/liwc'
    files_liwc = find_files(feature_path_liwc, ext='.csv')
    files_liwc.sort()
    for file in files_liwc:
        temp = np.array(pd.read_csv(file))
        features_liwc.append(temp.flatten()[1:])
    features_liwc = np.array(features_liwc).astype(np.float)
    features_liwc[np.isinf(features_liwc)] = 0
    features_liwc[np.isnan(features_liwc)] = 0

    features_within_speaker_perplexity = []
    path_within_speaker_perplexity = '/home11a/xiaoquan/learning/features/ADReSS_features/within_speaker_perplexity'
    files_within_speaker_perplexity = find_files(path_within_speaker_perplexity, ext='.csv')
    files_within_speaker_perplexity.sort()
    for file in files_within_speaker_perplexity:
        temp = np.array(pd.read_csv(file))
        features_within_speaker_perplexity.append(temp.flatten()[1:])
    features_within_speaker_perplexity = np.array(features_within_speaker_perplexity).astype(np.float)
    features_within_speaker_perplexity[np.isinf(features_within_speaker_perplexity)] = 0
    features_within_speaker_perplexity[np.isnan(features_within_speaker_perplexity)] = 0

    features_within_speaker_POS_perplexity = []
    path_within_speaker_POS_perplexity = '/home11a/xiaoquan/learning/features/ADReSS_features/within_speaker_POS_perplexity'
    files_within_speaker_POS_perplexity = find_files(path_within_speaker_POS_perplexity, ext='.csv')
    files_within_speaker_POS_perplexity.sort()
    for file in files_within_speaker_POS_perplexity:
        temp = np.array(pd.read_csv(file))
        features_within_speaker_POS_perplexity.append(temp.flatten()[1:])
    features_within_speaker_POS_perplexity = np.array(features_within_speaker_POS_perplexity).astype(np.float)
    features_within_speaker_POS_perplexity[np.isinf(features_within_speaker_POS_perplexity)] = 0
    features_within_speaker_POS_perplexity[np.isnan(features_within_speaker_POS_perplexity)] = 0

    features_perplexity = []
    path_perplexity = '/home11a/xiaoquan/learning/features/ADReSS_features/perplexity'
    files_perplexity = find_files(path_perplexity, ext='.csv')
    files_perplexity.sort()
    for file in files_perplexity:
        temp = np.array(pd.read_csv(file))
        features_perplexity.append(temp.flatten()[1:])
    features_perplexity = np.array(features_perplexity).astype(np.float)
    features_perplexity[np.isinf(features_perplexity)] = 0
    features_perplexity[np.isnan(features_perplexity)] = 0

    features_POS_perplexity = []
    path_POS_perplexity = '/home11a/xiaoquan/learning/features/ADReSS_features/POS_perplexity'
    files_path_POS_perplexity = find_files(path_POS_perplexity, ext='.csv')
    files_path_POS_perplexity.sort()
    for file in files_path_POS_perplexity:
        temp = np.array(pd.read_csv(file))
        features_POS_perplexity.append(temp.flatten()[1:])
    features_POS_perplexity = np.array(features_POS_perplexity).astype(np.float)
    features_POS_perplexity[np.isinf(features_POS_perplexity)] = 0
    features_POS_perplexity[np.isnan(features_POS_perplexity)] = 0

    features_all = np.concatenate((features_lex, features_liwc,
                                   features_within_speaker_perplexity,
                                   features_within_speaker_POS_perplexity,
                                   features_perplexity,
                                   features_POS_perplexity), axis=1)

    trn_feats = features_all[:108,:]
    trn_labels = np.concatenate((np.zeros(shape=(54, )), np.ones(shape=(54,))))

    tst_feats =  features_all[108:,:]
    tst_labels = load_test_labels('/home11a/xiaoquan/learning/features/ADReSS_features/test_meta_data.txt')

    return trn_feats, trn_labels, tst_feats, tst_labels


def fdr_select_features(X_train, y_train, X_test, n_fs):
    fidx = []
    # n_classes = np.max(y_train) + 1
    n_classes = len(np.unique(y_train))
    for i in range(n_classes):
        X_p = X_train[y_train == i]
        X_n = X_train[y_train != i]
        mu_p = np.mean(X_p, axis=0)
        mu_n = np.mean(X_n, axis=0)
        sigma_p = np.std(X_p, axis=0)
        sigma_n = np.std(X_n, axis=0)

        fdr = ((mu_p - mu_n)**2)/(sigma_p**2 + sigma_n**2)
        idx = np.argsort(-1 * fdr)
        fidx.append(idx[0:n_fs])
    fidx = np.asarray(fidx).reshape((n_classes*n_fs, ))
    fidx = np.unique(fidx)
    return X_train[:, fidx], X_test[:, fidx]

def get_nfs_top_rank_index(rank, nfs):

    def sigmoid(x):
        return 1 / (1 + np.exp(-x))

    preserver_rate = sigmoid(rank)   # rank = -logit_p <--> - dropout rate, sigmoid(rank) = preserver_rate
    rank_index = np.argsort(-preserver_rate)  # preserver_rate in descending order


    return rank_index[0: nfs]

if __name__ == "__main__":

    # feature_path = '/home11a/xiaoquan/learning/features/AD2021/train/lex_chinese'
    # files = find_files(feature_path, ext='.csv')
    # files.sort()
    # features_all = []
    # for file in files:
    #     temp = np.array(pd.read_csv(file, sep=','))
    #     features_all.append(temp.flatten()[1:])
    # features_all = np.array(features_all).astype(np.float)
    # train_feats_all = features_all
    # train_labels_all = np.concatenate((1 * np.ones(shape=(78,)), 3 * np.ones(shape=(108,)), 2 * np.ones(shape=(93,))))

    # feature_path_tst = '/home11a/xiaoquan/learning/features/AD2021/test/long/lex_chinese'
    # file_tst = find_files(feature_path_tst,  ext='.csv')
    # file_tst.sort()
    # features_all_tst = []
    # for file in file_tst:
    #     temp = np.array(pd.read_csv(file, sep=','))
    #     features_all_tst.append(temp.flatten()[1:])

    # features_all_tst = np.array(features_all_tst).astype(np.float)
    # test_feats = features_all_tst
    # test_labels = np.array(pd.read_excel('/home11a/xiaoquan/learning/corpus/AD2021/ADtest_label.xlsx').label)

    file_base = '/home11a/xiaoquan/learning/AD_detection/Dropout_FIR_torch/results/ADReS2020/'
    
    train_feats_all, train_labels_all, test_feats_all, test_labels_all = load_ADReSS_linguistic_features()

    num =10

    kf = KFold(n_splits=10, shuffle=True, random_state=0)
    fold=0

    acc_tran=[]
    pre_tran=[]
    rec_tran=[]
    f1_tran=[]
    for tran_index, test_index in kf.split(train_feats_all):

        trn_feats = train_feats_all[tran_index,:]
        trn_labels = train_labels_all[tran_index]

        tst_feats = train_feats_all[test_index,:]
        tst_labels = train_labels_all[test_index]

        std = StandardScaler()
        std = std.fit(trn_feats)
        trn_feats = std.transform(trn_feats)
        tst_feats = std.transform(tst_feats)

        trn_feats, tst_feats = fdr_select_features(trn_feats, trn_labels, tst_feats, 50)

        file_name = file_base + str(fold) + '_Dropout_FIR_torch.mat'
        rank = sio.loadmat(file_name)['preserve_logit_p'].flatten()
        index = get_nfs_top_rank_index(rank, num)

        trn_feats = trn_feats[:, index]
        tst_feats = tst_feats[:, index]

        clf = SVC(kernel='linear', C=1)
        clf.fit(trn_feats, trn_labels)
        predict_labels = clf.predict(tst_feats)
        # acc = accuracy_score(tst_labels, predict_labels)
        # pre = precision_score(tst_labels, predict_labels, average='macro')
        # rec = recall_score(tst_labels, predict_labels, average='macro')
        # f1_ = f1_score(tst_labels, predict_labels, average='macro')

        acc = accuracy_score(tst_labels, predict_labels)
        pre = precision_score(tst_labels, predict_labels)
        rec = recall_score(tst_labels, predict_labels)
        f1_ = f1_score(tst_labels, predict_labels)

        acc_tran.append(acc)
        pre_tran.append(pre)
        rec_tran.append(rec)
        f1_tran.append(f1_)

        fold=fold+1

    print('acc', np.array(acc_tran).mean())
    print('pre', np.array(pre_tran).mean())
    print('rec', np.array(rec_tran).mean())
    print('f1', np.array(f1_tran).mean())

    # for num in range(1, 144):
    #     print(num)
    #     folds = [0,1,2,3,4,5,6,7,8,9]
    #     file_base = '/home11a/xiaoquan/learning/AD_detection/Dropout_FIR_torch/results/AD2021/'
    #     pre_test_labels_all = []
    #     for fold in folds:
    #         file_name = file_base + str(fold) + '_Dropout_FIR_torch.mat'
    #         rank = sio.loadmat(file_name)['preserve_logit_p'].flatten()
    #         index = get_nfs_top_rank_index(rank, num)
    #
    #         trn_features = train_feats_all[:, index]
    #         tst_features = test_feats[:, index]
    #
    #         std = StandardScaler()
    #         std = std.fit(trn_features)
    #         trn_features = std.transform(trn_features)
    #         tst_features = std.transform(tst_features)
    #
    #         clf = SVC(kernel='linear', C=1)
    #         clf.fit(trn_features, train_labels_all)
    #         predict_labels = clf.predict(tst_features)
    #
    #         pre_test_labels_all.append(predict_labels)
    #
    #     pre_test_labels_all = np.array(pre_test_labels_all)
    #
    #     final_labels= np.zeros(shape=(119,))
    #
    #     for j in range(119):
    #         label_j_index = list(pre_test_labels_all[:,j])
    #         final_labels[j] = max(label_j_index, key=label_j_index.count)
    #
    #     acc = accuracy_score(test_labels, final_labels)
    #     pre = precision_score(test_labels, final_labels, average='macro')
    #     rec = recall_score(test_labels, final_labels, average='macro')
    #     f1_ = f1_score(test_labels, final_labels, average='macro')
    #
    #     print('acc', acc)
    #     print('pre', pre)
    #     print('rec', rec)
    #     print('f1', f1_)
import numpy as np
import os
# import tensorflow.keras as keras
# from tensorflow.keras import backend as K
from src.FeatureSelector import FeatureSelector
from DataGenerator import generate_data, get_one_hot
import h5py
from sklearn.preprocessing import StandardScaler
import scipy.io as sio
import torch
import pdb


def DDR_run(train_features, train_labels, FEATURE_SHAPE, operator_arch, selector_arch, data_batch_size, mask_batch_size, init_dropout_rate):


    # final batch_size is data_batch_size x mask_batch_size
    s = 5  # size of optimal subset that we are looking for
    s_p = 2  # number of flipped bits in a mask when looking around m_opt
    phase_2_start = 6000  # after how many batches phase 2 will begin
    max_batches = 25000  # how many batches if the early stopping condition not satisfied
    early_stopping_patience = 600  # how many patience batches (after phase 2 starts)
    # before the training stops
    
    X_tr = train_features
    y_tr = train_labels
    X_val = X_tr
    y_val = y_tr

    # Get one hot encoding of the labels

    y_tr = get_one_hot(y_tr.astype(np.int8), len(np.unique(train_labels)))

    ### sample weight
    # label_unique = np.unique(train_labels)
    # sample_weight=[]
    # for label in label_unique:
    #     sample_weight.append(len(np.where(train_labels==label)[0]))
    # sample_weight = 1/(np.array(sample_weight) / sum(sample_weight))
    # sample_weight = sample_weight / sum(sample_weight)
    
    # for i in range(len(label_unique)):
    #     index = np.where(train_labels==label_unique[i])[0]
    #     y_tr[index,:] = y_tr[index,:] * sample_weight[i]


    
    # Create the framework, needs number of features and batch_sizes, str_id for tensorboard
    fs = FeatureSelector(FEATURE_SHAPE, s, data_batch_size, mask_batch_size,
                         str_id='DDR',
                         epoch_on_which_selector_trained=2)

    #fs.create_dense_operator([128, 32, 3], "softmax")
    fs.create_dense_operator(operator_arch, "softmax")

    # Ealy stopping activate after the phase2 of the training starts.
    fs.operator.set_early_stopping_params(phase_2_start, patience_batches=early_stopping_patience, minimize=True)

    # dropout
    #fs.create_dense_selector([128, 32, 1], init_dropout_rate)
    # import pdb
    # pdb.set_trace()
    fs.create_dense_selector(selector_arch, init_dropout_rate)

    # Set when the phase2 starts, what is the number of flipped bits when perturbin masks
    fs.create_mask_optimizer(epoch_condition=phase_2_start, perturbation_size=s_p)

    # Train networks and set the maximum number of iterations
    fs.train_networks_on_data(X_tr, y_tr, max_batches)

    # droout
    preserve_logit_p = fs.get_dropout_logit_p()

    #filename = 'results/ADReS2020/' + identifier + '_Dropout_FIR_torch.mat'
    #sio.savemat(filename, {'preserve_logit_p': preserve_logit_p})

    return preserve_logit_p


import os
import pandas as pd
def load_features():

    def find_files(path, ext="", prefix=""):
        return [os.path.join(path, x) for x in os.listdir(path) if x.endswith(ext) and x.startswith(prefix)]

    feature_path = '/home11a/xiaoquan/learning/features/AD2021/train/lex_chinese'
    files = find_files(feature_path, ext='.csv')
    files.sort()
    features_all = []
    for file in files:
        temp = np.array(pd.read_csv(file, sep=','))
        features_all.append(temp.flatten()[1:])

    features_all = np.array(features_all).astype(np.float)
    trn_feats = features_all
    trn_labels = np.concatenate((1 * np.ones(shape=(78,)), 3 * np.ones(shape=(108,)), 2 * np.ones(shape=(93,))))

    return trn_feats, trn_labels

def load_ADReSS_linguistic_features():

    import os
    def find_files(path, ext="", prefix=""):
        return [os.path.join(path, x) for x in os.listdir(path) if x.endswith(ext) and x.startswith(prefix)]

    def load_test_labels(file):
        test_df_true = pd.read_csv(file)  # Read testing set meta data
        test_subject_id2 = test_df_true[test_df_true.columns.values[0]].apply(lambda x: x.split(';')[0]).values
        test_subject_labels = test_df_true[test_df_true.columns.values[0]].apply(
            lambda x: x.split(';')[3]).values.astype(np.int32)
        # make sure test_subject_id2 is in ascending order
        id_index2 = np.argsort(test_subject_id2)
        test_subject_id2 = test_subject_id2[id_index2]
        test_subject_labels = test_subject_labels[id_index2]
        return test_subject_labels

    features_lex = []
    feature_path_lex = '/home11a/xiaoquan/learning/features/ADReSS_features/lexicosyntactic_PAR'
    files_lex = find_files(feature_path_lex, ext='.csv')
    files_lex.sort()
    for file in files_lex:
        temp = np.array(pd.read_csv(file))
        features_lex.append(temp.flatten())
    features_lex = np.array(features_lex).astype(np.float)
    features_lex[np.isinf(features_lex)] = 0
    features_lex[np.isnan(features_lex)] = 0
    features_lex = np.delete(features_lex,  [270,272,274,276], axis=1)

    features_liwc = []
    feature_path_liwc = '/home11a/xiaoquan/learning/features/ADReSS_features/liwc'
    files_liwc = find_files(feature_path_liwc, ext='.csv')
    files_liwc.sort()
    for file in files_liwc:
        temp = np.array(pd.read_csv(file))
        features_liwc.append(temp.flatten()[1:])
    features_liwc = np.array(features_liwc).astype(np.float)
    features_liwc[np.isinf(features_liwc)] = 0
    features_liwc[np.isnan(features_liwc)] = 0

    features_within_speaker_perplexity = []
    path_within_speaker_perplexity = '/home11a/xiaoquan/learning/features/ADReSS_features/within_speaker_perplexity'
    files_within_speaker_perplexity = find_files(path_within_speaker_perplexity, ext='.csv')
    files_within_speaker_perplexity.sort()
    for file in files_within_speaker_perplexity:
        temp = np.array(pd.read_csv(file))
        features_within_speaker_perplexity.append(temp.flatten()[1:])
    features_within_speaker_perplexity = np.array(features_within_speaker_perplexity).astype(np.float)
    features_within_speaker_perplexity[np.isinf(features_within_speaker_perplexity)] = 0
    features_within_speaker_perplexity[np.isnan(features_within_speaker_perplexity)] = 0

    features_within_speaker_POS_perplexity = []
    path_within_speaker_POS_perplexity = '/home11a/xiaoquan/learning/features/ADReSS_features/within_speaker_POS_perplexity'
    files_within_speaker_POS_perplexity = find_files(path_within_speaker_POS_perplexity, ext='.csv')
    files_within_speaker_POS_perplexity.sort()
    for file in files_within_speaker_POS_perplexity:
        temp = np.array(pd.read_csv(file))
        features_within_speaker_POS_perplexity.append(temp.flatten()[1:])
    features_within_speaker_POS_perplexity = np.array(features_within_speaker_POS_perplexity).astype(np.float)
    features_within_speaker_POS_perplexity[np.isinf(features_within_speaker_POS_perplexity)] = 0
    features_within_speaker_POS_perplexity[np.isnan(features_within_speaker_POS_perplexity)] = 0

    features_perplexity = []
    path_perplexity = '/home11a/xiaoquan/learning/features/ADReSS_features/perplexity'
    files_perplexity = find_files(path_perplexity, ext='.csv')
    files_perplexity.sort()
    for file in files_perplexity:
        temp = np.array(pd.read_csv(file))
        features_perplexity.append(temp.flatten()[1:])
    features_perplexity = np.array(features_perplexity).astype(np.float)
    features_perplexity[np.isinf(features_perplexity)] = 0
    features_perplexity[np.isnan(features_perplexity)] = 0

    features_POS_perplexity = []
    path_POS_perplexity = '/home11a/xiaoquan/learning/features/ADReSS_features/POS_perplexity'
    files_path_POS_perplexity = find_files(path_POS_perplexity, ext='.csv')
    files_path_POS_perplexity.sort()
    for file in files_path_POS_perplexity:
        temp = np.array(pd.read_csv(file))
        features_POS_perplexity.append(temp.flatten()[1:])
    features_POS_perplexity = np.array(features_POS_perplexity).astype(np.float)
    features_POS_perplexity[np.isinf(features_POS_perplexity)] = 0
    features_POS_perplexity[np.isnan(features_POS_perplexity)] = 0

    features_all = np.concatenate((features_lex, features_liwc,
                                   features_within_speaker_perplexity,
                                   features_within_speaker_POS_perplexity,
                                   features_perplexity,
                                   features_POS_perplexity), axis=1)

    trn_feats = features_all[:108,:]
    trn_labels = np.concatenate((np.zeros(shape=(54, )), np.ones(shape=(54,))))

    tst_feats =  features_all[108:,:]
    tst_labels = load_test_labels('/home11a/xiaoquan/learning/features/ADReSS_features/test_meta_data.txt')

    return trn_feats, trn_labels, tst_feats, tst_labels


from sklearn.model_selection import KFold
from sklearn.preprocessing import StandardScaler

import multiprocessing as mp

import pdb

def fdr_select_features(X_train, y_train, X_test, n_fs):
    fidx = []
    # n_classes = np.max(y_train) + 1
    n_classes = len(np.unique(y_train))
    for i in range(n_classes):
        X_p = X_train[y_train == i]
        X_n = X_train[y_train != i]
        mu_p = np.mean(X_p, axis=0)
        mu_n = np.mean(X_n, axis=0)
        sigma_p = np.std(X_p, axis=0)
        sigma_n = np.std(X_n, axis=0)
        fdr = ((mu_p - mu_n)**2)/(sigma_p**2 + sigma_n**2)
        idx = np.argsort(-1 * fdr)
        fidx.append(idx[0:n_fs])
    fidx = np.asarray(fidx).reshape((n_classes*n_fs, ))
    fidx = np.unique(fidx)
    return X_train[:, fidx], X_test[:, fidx]


if __name__ == '__main__':

    os.environ["CUDA_VISIBLE_DEVICES"] = "0"
    torch.set_default_tensor_type(torch.cuda.DoubleTensor)

    seed = 1234
    np.random.seed(seed)
    torch.manual_seed(seed)

    #feats, labels = load_features()
    feats, labels, _, _ = load_ADReSS_linguistic_features()

    kf = KFold(n_splits=10, shuffle=True, random_state=0)

    fold=0
    for tran_index, test_index in kf.split(feats):

        trn_feats = feats[tran_index,:]
        trn_labels = labels[tran_index]

        std = StandardScaler()
        trn_feats = std.fit_transform(trn_feats)

        trn_feats, _ = fdr_select_features(trn_feats, trn_labels, trn_feats, 50)
        
        run(trn_feats, trn_labels, (trn_feats.shape[1],), str(fold))

        fold=fold+1

    # fun = run()
    #
    # pool = mp.Pool(10)
    # predict_labels = [pool.apply_async(fun, args=(alpha,)) for alpha in alpha_all]












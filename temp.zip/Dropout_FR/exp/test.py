import torch as t
x = t.ones([1,2], requires_grad=True)
# print(x.requires_grad)   #True
y = t.ones([1,2], requires_grad=True)
# print(y.requires_grad)   #True

# x = x.detach()
x.grad.zero_()
print(x.requires_grad)

y = x+y      	  #tensor([２.])
print(y.requires_grad)
print(y.retain_grad())

z = t.pow(y, 2)
z.backward()

print(y.grad)
(x.grad)
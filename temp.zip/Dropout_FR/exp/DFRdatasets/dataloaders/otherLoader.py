import numpy as np
import pandas as pd
import torch
import torch.nn as nn

from arch.sensitivity.DFR_BDNet import L1BDNet
from exp.DFRdatasets.models.MLP import MLP, ClassificationMLP
from .MLPLoaderBase import MLPLoaderBase
from sklearn.preprocessing import StandardScaler
from sklearn.utils import shuffle
import scipy.io as sio

class OtherLoader(MLPLoaderBase):
    '''
    Data specific loader to define nn_test and nn_rank.
    ::: test func: return {name, val}
    ::: rank func: return {rank}
    '''
    def __init__(self, mode='classification', **kwargs):
        kwargs['mode'] = mode
        super(OtherLoader, self).__init__(**kwargs)

    def init_hyperamaters(self):
        return {
            'dimensions': [10, 50, 25, 10, 11],
            'epochs': 400,
            'epoch_print': 1,
            'weight_lr': 1e-3,
            'lookahead': 12,
            'lr_patience': 5,
            'verbose': 1,
            'weight_decay': 1e-4,
            'loss_criteria': nn.CrossEntropyLoss(),
        }

    def init_bdnet_hyperparams(self):   # bdnet: basic dropout network?
        return {
            'reg_coef': 0.01,
            'ard_init': 0.,
            'lr': 0.002,
            'verbose': 1,
            'epochs': 400,
            'epoch_print': 5,
            'rw_max': 50,
            'loss_criteria': nn.CrossEntropyLoss(),
            'weights_lr': 0.001,  # modified
            # 'annealing': 200,
        }

    def _load_data(self, trn_feats=None, trn_labels=None, testfold=4):

        trainset = (trn_feats, trn_labels)

        return trainset, trainset, [], []

    def get_top_indices(self):
        return [1, 2, 5, 10, 20, 30, 42]

    def _get_random_sample_hyperparams(self):
        n_hidden = np.random.randint(42, 200)
        n_layers = np.random.randint(0, 5)

        dimensions = [42, 2]
        for i in range(n_layers):
            dimensions.insert(1, n_hidden)

        return {'dimensions': dimensions}
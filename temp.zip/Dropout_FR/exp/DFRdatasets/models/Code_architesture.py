def run()
	def run_with_test_fold()
		getattr(): choose ranking method
			def nn_rank(): nn rank
				self.get_nn(): get network
					if network caches do not exist:
						self._nn_train():
							self.nn_class(): define network architecture
							nn.fit(): train the network in progress
					torch.load(): load network state from cache files
self.nn_class(): network caches do exist
				self._nn_rank: rank netwoek

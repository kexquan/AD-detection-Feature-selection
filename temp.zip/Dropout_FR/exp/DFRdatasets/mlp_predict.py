import argparse
import os

import numpy as np
import torch

from exp.DFRdatasets.dataloaders.LoaderBase import LoaderBase  # 从根目录开始算起, 不要用相对目录
import feature_utils

def run_with_test_fold(trn_feats, trn_labels, rank_name, reg_coef, args, loader, dimensions):

    testfold=0
    # Ex: 'nn_rank:0.01'. Then extract nn_rank and 0.01 seperately, 0.01: regulerization coefficient
    the_rank_func_name = rank_name
    # if ':' in rank_name:
    #     tmp = rank_name.split(':')
    #     the_rank_func_name = tmp[0]

        # if '|' not in tmp[1]:
    loader.bdnet_hyperparams['reg_coef'] = reg_coef  # regularization coefficient, initialized dropout rate=0.5
        # else:  # "regularization coefficient|initialized dropout rate (set by user)"
        #     tmp2 = tmp[1].split('|')
        #     loader.bdnet_hyperparams['reg_coef'] = float(tmp2[0])  # regularization coefficient
        #     dropout_rate = float(tmp2[1])
        #     loader.bdnet_hyperparams['ard_init'] = \
        #         np.log(dropout_rate) - np.log(1. - dropout_rate)  # initialized dropout rate

    loader.hyper_params['dimensions'] = dimensions

    # train a classifier and rank it. Only not nn_specific_rank
    # rank = None
    # if the_rank_func_name != 'nn_specific_rank':
    if args.no_rank_cache: # not store experiment results?
        rank = getattr(loader, the_rank_func_name)(testfold=testfold)['rank']
    else:
        folder = 'results/{}'.format(args.dataset)
        if not os.path.exists(folder):
            os.mkdir(folder)
        allfilenames = os.listdir(folder)
        the_rank_file = None
        for filename in allfilenames:
            if ('_%s_' % (rank_name.split(':')[0] + '_' + rank_name.split(':')[1]) ) in filename:
                the_rank_file = filename
                break
        # if the_rank_file is None:   # result files do not exist
        rank = getattr(loader, the_rank_func_name)(trn_feats=trn_feats, trn_labels=trn_labels, testfold=testfold)['rank']  # entry, getattr(): choose different kinds of ranking methods.
        # else: # result files exist, just load the result files
        #     print('rank cache found for {}, {}'.format(rank_name, testfold))
        #     _, cache_ranks = torch.load(os.path.join(folder, the_rank_file))
        #     rank = cache_ranks[testfold]

    if 'no_test' in args.test_func: # for test setting: zero out and retrain
        return None, rank

    def helper_subset(unit, top_gene_num):
        indices = np.flip(rank.argsort(), axis=0).copy()
        selected_ind = indices[:top_gene_num]

        result = {}
        for the_test_func in args.test_func:
            # Not sure dict would work
            metrics = getattr(loader, the_test_func)(testfold, selected_ind)

            for attr_name in metrics:
                result['%s_%s_%s' %
                       (the_rank_func_name, the_test_func, attr_name)] \
                    = metrics[attr_name]
        return result,

    top_ind_tried = loader.get_top_indices()
    containers = feature_utils.run_std_err_params(
        'top_gene_num', top_ind_tried, repeat=1, val_func=helper_subset,
        default_params={}, num_parallel_threads=1)
    return containers, rank

def run(rank_name, args, loader):
    # Only supports 5 fold cross validation
    containers_dict, rank_dict = {}, {}  # dicts for storing experiment value (different folds)
    for testfold in loader.get_total_folds(): # loop for each fold
        containers_dict[testfold], rank_dict[testfold] = run_with_test_fold(
            testfold, rank_name, args, loader)    # run

    return containers_dict, rank_dict[0]

def parse_args(seed):
    # Training settings
    parser = argparse.ArgumentParser(description='train rnn to predict')
    # parser.add_argument('--lr', type=float, default=0.001)
    # parser.add_argument('--epochs', type=int, default=100)
    # parser.add_argument('--reg_coef', type=float, default=0.001)
    # parser.add_argument('--batch-size', type=int, default=32)
    # parser.add_argument('--batch-print', type=int, default=30)
    # parser.add_argument('--save-freq', type=int, default=1)
    parser.add_argument('--no-cuda', action='store_true', default=False)
    parser.add_argument('--resume', type=str, default=None)
    parser.add_argument('--gpu-ids', nargs='+', type=int, default=[0],
                        help='number of gpus to produce')
    parser.add_argument('--identifier', type=str, default='0111')
    # parser.add_argument('--reg_coef', type=float, default=None, help='vbd regularization coef!')
    parser.add_argument('--dataset', type=str, default='MIMIC_new',
                        help='["wineqaulity", "OnlineNewsPopularity", '
                             '"ClassificationONPLoader", "RegSupport2Loader"]')
    parser.add_argument('--seed', type=int, default='1234')
    # parser.add_argument('--lookahead', type=int, default=5)
    # parser.add_argument('--weighted', action='store_true', default=False)
    # parser.add_argument('--reuse-rnn', action='store_true', default=False)
    parser.add_argument('--rank_func', nargs='+', type=str,
                        default=['nn_rank:0.1'], help='specify lambda | dropout ini')
    parser.add_argument('--test_func', nargs='+', type=str, default=['nn_test_zero'],
                        help='["nn_test_zero", "nn_test_retrain"]')
    parser.add_argument('--visdom_enabled', action='store_true', default=False)
    parser.add_argument('--no_rank_cache', action='store_true', default=False)
    parser.add_argument('--no_nn_cache', action='store_true', default=False)
    # parser.add_argument('--start_val', type=int, default=2)

    args = parser.parse_args()
    args.nn_cache = (not args.no_nn_cache) # nn_cache=Ture if we use cache for nn
    args.rank_cache = (not args.no_rank_cache)
    args.cuda = (not args.no_cuda) and torch.cuda.is_available()
    # np.random.seed(args.seed)
    np.random.seed(seed)
    # torch.manual_seed(args.seed)
    torch.manual_seed(seed)

    if args.cuda:
        print('gpu current device:', torch.cuda.current_device())
        # torch.cuda.manual_seed(args.seed)
        torch.cuda.manual_seed(seed)
        if len(args.gpu_ids) > 0:
            print('start using gpu device:', args.gpu_ids)
            torch.cuda.set_device(args.gpu_ids[0])

    # Custom change
    args.total_folds = 5
    if args.dataset == 'MIMIC':
        args.total_folds = 1

    print('args:', args)
    print('==================== Start =====================')
    print('')
    return args

# import sys
# sys.path.append('/home11a/xiaoquan/learning/AD_detection/AD_detection_python_code')
# from dataloader import load_support2_dataset

import pandas as pd
def load_support2_dataset(file_base_path):

	x = pd.read_csv(file_base_path + 'x_new.csv').values
	y = pd.read_csv(file_base_path + 'y_new.csv').values.ravel()
	x = x.astype(np.float32)
	y = y.astype(np.int64)

	return x, y

def load_sythetic_data(num_trn_samples, num_tst_samples, datatype):

	def generate_data(n=100, datatype='', seed=0):
		"""
        Generate data (X,y)
        Args:
            n(int): number of samples
            datatype(string): The type of data
            choices: 'orange_skin', 'XOR', 'regression'.
            seed: random seed used
        Return:
            X(float): [n,d].
            y(float): n dimensional array.
        """
		np.random.seed(seed)

		if datatype == 'binary_classification':
			X = []

			i = 0
			while i < n // 2:
				x = np.random.randn(10)
				if 9 < sum(x[:4] ** 2) < 16:
					X.append(x)
					i += 1
			X = np.array(X)

			X = np.concatenate((X, np.random.randn(n // 2, 10)))

			y = np.concatenate((-np.ones(n // 2), np.ones(n // 2)))

			perm_inds = np.random.permutation(n)
			X, y = X[perm_inds], y[perm_inds]

		elif datatype == 'XOR':
			X = np.random.randn(n, 10)
			y = np.zeros(n)
			splits = np.linspace(0, n, num=8 + 1, dtype=int)
			signals = [[1, 1, 1], [-1, -1, -1], [1, 1, -1], [-1, -1, 1], [1, -1, -1], [-1, 1, 1], [-1, 1, -1],
					   [1, -1, 1]]
			for i in range(8):
				X[splits[i]:splits[i + 1], :3] += np.array([signals[i]])
				y[splits[i]:splits[i + 1]] = i // 2

			perm_inds = np.random.permutation(n)
			X, y = X[perm_inds], y[perm_inds]

		return (X, y)

	trn_feats, trn_labels = generate_data(n=num_trn_samples, datatype=datatype, seed=1234)
	tst_feats, tst_labels = generate_data(n=num_tst_samples, datatype=datatype, seed=4321)

	trn_labels[np.where(trn_labels==-1)]=0
	tst_labels[np.where(tst_labels==-1)]=0

	return trn_feats, trn_labels, tst_feats, tst_labels


def load_mnist_dataset(file_base_path):

	from torchvision import datasets, transforms
	data_train = datasets.MNIST(root=file_base_path,
								transform=transforms,
								train=True,
								download=False)

	labels_all = np.array(data_train.targets)
	labels_3_index = np.where(labels_all == 3)[0]
	labels_8_index = np.where(labels_all == 8)[0]

	feats_all = np.array(data_train.data).reshape(-1, 784)
	feats_3 = feats_all[labels_3_index, :]
	feats_8 = feats_all[labels_8_index, :]

	feats = np.concatenate((feats_3, feats_8), axis=0).astype(np.float) / 255
	labels = np.concatenate((np.zeros(shape=feats_3.shape[0]), np.ones(shape=feats_8.shape[0])), axis=0).astype(np.int)

	return feats, labels

if __name__ == '__main__':

    reg_cof = 0.001
    random_state = 0
    torch.set_default_tensor_type(torch.cuda.DoubleTensor)
    args = parse_args(random_state)
    args.test_func = "no_test"
    args.identifier = "test"
    rank_name = 'nn_joint_rank'
    loader = LoaderBase.create(
        'other', {'visdom_enabled': args.visdom_enabled,
                       'cuda_enabled': args.cuda,
                       'nn_cache': args.nn_cache})

    # file_base_path = '/home11a/xiaoquan/learning/corpus/support2/'
    # trn_feats, trn_labels = load_support2_dataset(file_base_path)

    # trn_feats, trn_labels, _, _ = load_sythetic_data(4096, 512, 'XOR')

    file_base_path = '/home11a/xiaoquan/learning/corpus/benchmark/'
    trn_feats, trn_labels = load_mnist_dataset(file_base_path)

    dimensions = [trn_feats.shape[1], 128, 32, len(np.unique(trn_labels))]
    _, rank = run_with_test_fold(trn_feats.astype(np.float64), trn_labels.astype(np.int64), rank_name, reg_cof, args, loader, dimensions)

    # np.savez('DropoutFR_mnist', rank)

    import matplotlib.pyplot as plt
    # plt.plot(range(len(rank)), torch.sigmoid(torch.tensor(rank)).cpu())
    # plt.show()
    
    temp1 = np.array(torch.sigmoid(torch.tensor(rank)).cpu().reshape([28, 28]))
    plt.imshow(temp1)
    plt.show()
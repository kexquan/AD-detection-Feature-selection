import random

import numpy as np
import pandas as pd
import os
import scipy.io

from sklearn.model_selection import train_test_split

def load_ADReSS2020_train_data():

	def load_disfluency_feats(cc_file_path, cd_file_path, test_file_path):
		feats_cc = pd.read_csv(cc_file_path).values[:,1:]
		feats_cd = pd.read_csv(cd_file_path).values[:,1:]
		feats_tst = pd.read_csv(test_file_path).values[:,1:]
		return np.concatenate((feats_cc, feats_cd), axis=0), feats_tst

	def load_CLAN_linguistic(cc_file_path, cd_file_path, tst_file_path):
		feats_cc = pd.read_csv(cc_file_path).values[:, 12:]
		feats_cd = pd.read_csv(cd_file_path).values[:, 12:]
		feats_tst = pd.read_csv(tst_file_path).values[:, 12:]
		return np.concatenate((feats_cc, feats_cd), axis=0), feats_tst

	def load_BERT_feats(trn_file_path, tst_file_path):
		trn_df = pd.read_csv(trn_file_path)
		trn_df.sort_values('id', inplace=True)
		trn_feats = trn_df.values[:, 4:]
		tst_df = pd.read_csv(tst_file_path)
		tst_df.sort_values('id', inplace=True)
		tst_feats = tst_df.values[:, 4:]
		return trn_feats, tst_feats

	def load_COVFEFE_feats(file_path):

		def find_files(path, ext="", prefix=""):
			return [os.path.join(path, x) for x in os.listdir(path) if x.endswith(ext) and x.startswith(prefix)]

		files = find_files(file_path, ext='.csv')
		files.sort()
		features_all = []

		if np.array(pd.read_csv(files[0], ';')).shape[1] > np.array(pd.read_csv(files[0], ',')).shape[1]:
			sep=';'
		else:
			sep = ','
		for file in files:
			temp = np.array(pd.read_csv(file, sep=sep))
			features_all.append(temp.flatten())
		try:
			features_all = np.array(features_all).astype(np.float)
		except:
			features_all = np.array(features_all)[:, 1:].astype(np.float)

		return features_all[:108,:], features_all[108:,:]

	def load_test_labels(file):
		test_df_true = pd.read_csv(file)  # Read testing set meta data
		test_subject_id2 = test_df_true[test_df_true.columns.values[0]].apply(lambda x: x.split(';')[0]).values
		test_subject_labels = test_df_true[test_df_true.columns.values[0]].apply(
			lambda x: x.split(';')[3]).values.astype(np.int32)
		# make sure test_subject_id2 is in ascending order
		id_index2 = np.argsort(test_subject_id2)
		test_subject_id2 = test_subject_id2[id_index2]
		test_subject_labels = test_subject_labels[id_index2]
		return test_subject_labels

	feature_base = '/home11a/xiaoquan/learning/features/ADReSS_features/'

	disflu_cc_file_path = feature_base + 'slient_pauses/train_cc_eval.csv'
	disflu_cd_file_path = feature_base + 'slient_pauses/train_cd_eval.csv'
	disflu_tst_file_path = feature_base + 'slient_pauses/test_eval.csv'
	dis_feats_trn, dis_feats_tst = load_disfluency_feats(disflu_cc_file_path, disflu_cd_file_path, disflu_tst_file_path)

	ling_cc_file_path = feature_base + 'Linguistics/train_cc_eval.csv'
	ling_cd_file_path = feature_base + 'Linguistics/train_cd_eval.csv'
	ling_tst_file_path = feature_base + 'Linguistics/test_eval.csv'
	lingui_feats_trn,  lingui_feats_tst = load_CLAN_linguistic(ling_cc_file_path, ling_cd_file_path, ling_tst_file_path)

	bert_trn_file_path = feature_base + 'bert/trn_bert_features.csv'
	bert_tst_file_path = feature_base + 'bert/tst_bert_features.csv'
	bert_feats_trn, bert_feats_tst = load_BERT_feats(bert_trn_file_path, bert_tst_file_path)

	# liwc_file_path = '/home11a/xiaoquan/learning/features/ADReSS_features/liwc'
	# liwc_trn_feats, liwc_tst_feats = load_COVFEFE_feats(liwc_file_path)

	# lex_file_path = '/home11a/xiaoquan/learning/features/ADReSS_features/lexicosyntactic_PAR/lexicosyntactic'
	# lex_trn_feats, lex_tst_feats = load_COVFEFE_feats(lex_file_path)

	# perplex_file_path = '/home11a/xiaoquan/learning/features/ADReSS_features/perplexity'
	# perplex_trn_feats, perplex_tst_feats = load_COVFEFE_feats(perplex_file_path)

	# POS_perplex_file_path = '/home11a/xiaoquan/learning/features/ADReSS_features/POS_perplexity'
	# POS_perplex_trn_feats, POS_perplex_tst_feats = load_COVFEFE_feats(POS_perplex_file_path)

	# withinSpeak_perplex_file_path = '/home11a/xiaoquan/learning/features/ADReSS_features/within_speaker_perplexity'
	# withinSpeak_perplex_trn_feats, withinSpeak_perplex_tst_feats = load_COVFEFE_feats(withinSpeak_perplex_file_path)
	#
	# withinSpeak_POS_perplex_file_path = '/home11a/xiaoquan/learning/features/ADReSS_features/within_speaker_POS_perplexity'
	# withinSpeak_POS_perplex_trn_feats, withinSpeak_POS_perplex_tst_feats = load_COVFEFE_feats(withinSpeak_POS_perplex_file_path)

	# trn_feats = np.concatenate((
	# 							# lex_trn_feats,
	# 							lingui_feats_trn,
	# 							# liwc_trn_feats,
	# 							perplex_trn_feats,
	# 							POS_perplex_trn_feats,
	# 							withinSpeak_perplex_trn_feats,
	# 							withinSpeak_POS_perplex_trn_feats,
	# 							dis_feats_trn,
	# 							bert_feats_trn), axis=1)
	#
	# tst_feats = np.concatenate((
	# 							# lex_tst_feats,
	# 							lingui_feats_tst,
	# 							# liwc_tst_feats,
	# 							perplex_tst_feats,
	# 							POS_perplex_tst_feats,
	# 							withinSpeak_perplex_tst_feats,
	# 							withinSpeak_POS_perplex_tst_feats,
	# 							dis_feats_tst,
	# 							bert_feats_tst), axis=1)

	trn_feats = np.concatenate((lingui_feats_trn, dis_feats_trn, bert_feats_trn), axis=1)
	tst_feats = np.concatenate((lingui_feats_tst, dis_feats_tst, bert_feats_tst), axis=1)

	assert trn_feats.shape[1] == tst_feats.shape[1]

	trn_labels = np.concatenate((np.zeros(shape=(54, )), np.ones(shape=(54,))))
	tst_labels = load_test_labels(feature_base + 'test_meta_data.txt')

	return trn_feats.astype(np.float), trn_labels, tst_feats.astype(np.float), tst_labels, [], []

def load_AD2021_train_data():

	def find_files(path, ext="", prefix=""):
		return [os.path.join(path, x) for x in os.listdir(path) if x.endswith(ext) and x.startswith(prefix)]

	def load_COVFEFE_feats(file_path):

		files = find_files(file_path, ext='.csv')
		files.sort()
		features_all = []

		if np.array(pd.read_csv(files[0], ';')).shape[1] > np.array(pd.read_csv(files[0], ',')).shape[1]:
			sep = ';'
		else:
			sep = ','
		for file in files:
			temp = np.array(pd.read_csv(file, sep=sep))
			features_all.append(temp.flatten())
		try:
			features_all = np.array(features_all).astype(np.float)
		except:
			features_all = np.array(features_all)[:, 1:].astype(np.float)

		return features_all

	feature_base = '/home11a/xiaoquan/learning/features/AD2021/'
	#
	# lex_feature_path = feature_base + 'train/lex_chinese'
	# lex_feats_trn = load_COVFEFE_feats(lex_feature_path)
	# lex_feature_path_tst = feature_base + 'test/long/lex_chinese'
	# lex_feats_tst = load_COVFEFE_feats(lex_feature_path_tst)
	#
	# mat_acoustic_feature_path = feature_base + 'train/matlab_acoustics'
	# mat_acoustic_feats_trn = load_COVFEFE_feats(mat_acoustic_feature_path)
	# mat_acoustic_feature_path_tst = feature_base + 'test/long/matlab_acoustics'
	# mat_acoustic_feats_tst = load_COVFEFE_feats(mat_acoustic_feature_path_tst)
	#
	# bert_feature_path = feature_base + 'train/BERT'
	# bert_feats_trn = load_COVFEFE_feats(bert_feature_path)
	# bert_feature_path_tst = feature_base + 'test/long/BERT'
	# bert_feats_tst = load_COVFEFE_feats(bert_feature_path_tst)
	# bert_feats_tst = bert_feats_tst[:, 1:]
	#
	# COVAREP_feature_path = feature_base + 'train/COVAREP'
	# COVAREP_feats_trn = load_COVFEFE_feats(COVAREP_feature_path)
	# COVAREP_feature_path_tst = feature_base + 'test/long/COVAREP'
	# COVAREP_feats_tst = load_COVFEFE_feats(COVAREP_feature_path_tst)
	# COVAREP_feats_tst = COVAREP_feats_tst[:, 1:]
	# COVAREP_feats_trn[np.isnan(COVAREP_feats_trn)] = -1
	# COVAREP_feats_trn[np.isinf(COVAREP_feats_trn)] = -1
	# COVAREP_feats_tst[np.isnan(COVAREP_feats_tst)] = -1
	# COVAREP_feats_tst[np.isinf(COVAREP_feats_tst)] = -1
	#
	# disfluency_feats_trn = mat_acoustic_feats_trn[:, 2:32]
	# disfluency_feats_tst = mat_acoustic_feats_tst[:, 2:32]
	# acoustic_trn = np.concatenate((mat_acoustic_feats_trn[:, 0:2], mat_acoustic_feats_trn[:, 32:]), axis=1)
	# acoustic_tst = np.concatenate((mat_acoustic_feats_tst[:, 0:2], mat_acoustic_feats_tst[:, 32:]), axis=1)
	#
	# IS10_feature_path_trn = feature_base + 'train/is10'
	# IS10_feats_trn = load_COVFEFE_feats(IS10_feature_path_trn)[:, 1:]
	# IS10_feature_path_tst = feature_base + 'test/long/is10'
	# IS10_feats_tst = load_COVFEFE_feats(IS10_feature_path_tst)[:, 1:]
	#
	# trn_feats_all = np.concatenate((lex_feats_trn, disfluency_feats_trn, acoustic_trn, COVAREP_feats_trn, bert_feats_trn, IS10_feats_trn), axis=1)
	# tst_feats_all = np.concatenate((lex_feats_tst, disfluency_feats_tst, acoustic_tst, COVAREP_feats_tst, bert_feats_tst, IS10_feats_tst), axis=1)

	trn_feats_all = np.load('AD2021_trn_feats_and_IS10.npy')
	tst_feats_all = np.load('AD2021_tst_feats_and_IS10.npy')

	# tran subject ids
	files = find_files(feature_base + 'train/lex_chinese', ext='.csv')
	files.sort()
	subject_id = []
	for file in files:
		subject_id.append('_'.join(file.split('/')[-1].split('_')[0:3]))
	trn_subject_id = np.array(subject_id)

	assert trn_feats_all.shape[1] == tst_feats_all.shape[1]

	# 1:AD, 3:HC, 2:MCI
	trn_labels = np.concatenate((1 * np.ones(shape=(78,)), 3 * np.ones(shape=(108,)), 2 * np.ones(shape=(93,)))) - 1
	try:
		tst_labels = np.array(pd.read_excel('/home11a/xiaoquan/learning/corpus/AD2021/ADtest_label.xlsx').label) - 1
	except:
		tst_labels = []

	return trn_feats_all, trn_labels, tst_feats_all, tst_labels, trn_subject_id, []

def load_jccocc_moca_data(random_state):

	def find_files(path, ext="", prefix=""):
		return [os.path.join(path, x) for x in os.listdir(path) if x.endswith(ext) and x.startswith(prefix)]

	def load_COVFEFE_feats(file_path, ext='.csv'):

		files = find_files(file_path, ext=ext)
		files.sort()
		features_all = []

		if np.array(pd.read_csv(files[0], ';')).shape[1] > np.array(pd.read_csv(files[0], ',')).shape[1]:
			sep = ';'
		else:
			sep = ','
		for file in files:
			temp = np.array(pd.read_csv(file, sep=sep))
			features_all.append(temp.flatten())
		try:
			features_all = np.array(features_all).astype(np.float)
		except:
			features_all = np.array(features_all)[:, 1:].astype(np.float)

		return features_all

	def load_labels(file_path):
		files = find_files(file_path, ext=".txt")
		files.sort()
		labels = []
		for file in files:
			with open(file, 'r') as f:
				labels.append(int(f.readline()))
		return np.array(labels)

	# perplex_file_path_trn = '/home11a/xiaoquan/learning/features/JCCOCC_MOCA/two_class_exp1/train/perplexity'
	# perplex_feats_trn = load_COVFEFE_feats(perplex_file_path_trn)
	#
	# perplex_file_path_tst = '/home11a/xiaoquan/learning/features/JCCOCC_MOCA/two_class_exp1/test/perplexity'
	# perplex_feats_tst = load_COVFEFE_feats(perplex_file_path_tst)
	#
	# trn_feats_all = perplex_feats_trn
	# tst_feats_all = perplex_feats_tst

	# labels
	# trn_labels = load_labels('/home11a/xiaoquan/learning/corpus/JCCOCC_MOCA_20211118/moca_two_groups/segments/two_class_exp1/train/label')
	# tst_labels = load_labels('/home11a/xiaoquan/learning/corpus/JCCOCC_MOCA_20211118/moca_two_groups/segments/two_class_exp1/test/label')

	# # tran subject ids
	# files = find_files('/home11a/xiaoquan/learning/features/JCCOCC_MOCA/two_class_exp1/train/lex_cantonese', ext='.csv')
	# files.sort()
	# subject_id = []
	# for file in files:
	# 	subject_id.append(file.split('/')[-1].split('_')[0])
	# trn_subject_id = np.array(subject_id)
	#
	# # test subject id
	# files_tst = find_files('/home11a/xiaoquan/learning/features/JCCOCC_MOCA/two_class_exp1/test/lex_cantonese', ext='.csv')
	# files_tst.sort()
	# tst_subject_id = []
	# for file in files_tst:
	# 	tst_subject_id.append(file.split('/')[-1].split('_')[0])
	# tst_subject_id = np.array(tst_subject_id)

	# feature_base = '/home11a/xiaoquan/learning/features/JCCOCC_MOCA_27_02_2022_only_subjects/'
	feature_base = '/home11a/xiaoquan/learning/features/JCCOCC_MOCA_27_02_2022/'

	# ComperE_file_path = feature_base + 'ComparE'
	# ComperE_feats = load_COVFEFE_feats(ComperE_file_path)

	is10_file_path = feature_base + 'is10'
	is10_feats = load_COVFEFE_feats(is10_file_path)[:,1:]
	print('is10_feats shape: ', is10_feats.shape)

	# is10_lld_file_path =  feature_base + 'is10_lld'
	# is10_lld_feats = load_COVFEFE_feats(is10_lld_file_path)

	eGeMAPS_file_path = feature_base + 'eGeMAPS'
	eGeMAPS_feats = load_COVFEFE_feats(eGeMAPS_file_path)[:,1:]
	print('eGeMAPS_feats shape: ', eGeMAPS_feats.shape)

	GeMAPS_file_path = feature_base + 'GeMAPS'
	GeMAPS_feats = load_COVFEFE_feats(GeMAPS_file_path)[:,1:]
	print('GeMAPS_feats shape: ', GeMAPS_feats.shape)

	praat_syllable_nuclei_file_path = feature_base + 'praat_syllable_nuclei'
	praat_syllable_nuclei_feats = load_COVFEFE_feats(praat_syllable_nuclei_file_path)
	print('praat_syllable_nuclei_feats shape: ', praat_syllable_nuclei_feats.shape)

	all_feats = np.concatenate((is10_feats,
								eGeMAPS_feats,
								GeMAPS_feats), axis=1)

	# all_feats = GeMAPS_feats

	### load labels
	temp = pd.read_excel(feature_base + 'CUHK-JCCOCC-MoCA-Labels.xlsx')
	files_names = np.array(temp.FileName)
	labels = np.array(temp.Labels)
	sorted_index = np.argsort(files_names)
	files_names_sorted = files_names[sorted_index]
	labels_sorted = labels[sorted_index]

	## sampling
	labels_0_index = np.where(labels_sorted==0)[0]
	labels_1_index = np.where(labels_sorted==1)[0]
	labels_2_index = np.where(labels_sorted==2)[0]
	labels_3_index = np.where(labels_sorted==3)[0]

	labels_0_index_part = np.array(pd.DataFrame(labels_0_index).sample(n=43, replace=False, random_state=random_state, axis=0)).flatten()
	all_feats = np.concatenate((all_feats[labels_0_index_part, :],
								all_feats[labels_1_index, :],
								all_feats[labels_2_index, :],
								all_feats[labels_3_index, :]), axis=0)
	labels_sorted = np.concatenate((labels_sorted[labels_0_index_part],
								labels_sorted[labels_1_index],
								labels_sorted[labels_2_index],
								labels_sorted[labels_3_index]))

	labels_sorted[np.where(labels_sorted==2)[0]] = 1
	labels_sorted[np.where(labels_sorted==3)[0]] = 1

	trn_feats_all, tst_feats_all, trn_labels, tst_labels = train_test_split(all_feats,
																	   labels_sorted,
																	   test_size=0.33,
																	   random_state=random_state,
																	   stratify=labels_sorted)

	print('train shape:', trn_feats_all.shape, trn_labels.shape)
	print('test shape:', tst_feats_all.shape, tst_labels.shape)

	assert len(trn_labels) == trn_feats_all.shape[0]
	assert len(tst_labels) == tst_feats_all.shape[0]

	return trn_feats_all, trn_labels, tst_feats_all, tst_labels, [], []

def load_jccocc_moca_data_2022_03_11():

	def find_files(path, ext="", prefix=""):
		return [os.path.join(path, x) for x in os.listdir(path) if x.endswith(ext) and x.startswith(prefix)]

	def load_COVFEFE_feats(file_path, ext='.csv'):

		files = find_files(file_path, ext=ext)
		files.sort()
		features_all = []

		if np.array(pd.read_csv(files[0], ';')).shape[1] > np.array(pd.read_csv(files[0], ',')).shape[1]:
			sep = ';'
		else:
			sep = ','
		for file in files:
			temp = np.array(pd.read_csv(file, sep=sep))
			features_all.append(temp.flatten())
		try:
			features_all = np.array(features_all).astype(np.float)
		except:
			features_all = np.array(features_all)[:, 1:].astype(np.float)

		return features_all, files

	all_infor = pd.read_excel('/home11a/xiaoquan/learning/corpus/JCCOCC_MOCA_27_02_2022/2022_03_11/CUHK-JCCOCC-MoCA-Labels_extended.xlsx')

	feature_base = '/home11a/xiaoquan/learning/features/JCCOCC_MOCA_2022_03_11/'

	# # COVAREP
	COVAREP_feature_path = feature_base + 'COVAREP'
	COVAREP_feats_all, filenames1 = load_COVFEFE_feats(COVAREP_feature_path)
	print('COVAREP feats dimension:', COVAREP_feats_all.shape)  # 518

	## only used two minutes
	files_all = np.array([file.split('/')[-1].split('.')[0].split('_')[0] for file in filenames1])
	file_unique = np.unique(files_all)
	index_used = []
	for file in file_unique:
		index_ = np.where(file == files_all)[0]
		index_used.append(index_[0])
		index_used.append(index_[-1])
	index_used = np.array(index_used)

	# # IS10
	is10_feature_path = feature_base + 'is10'
	is10_feats_all, filenames2 = load_COVFEFE_feats(is10_feature_path)
	print('IS10 feats dimension:', is10_feats_all.shape)  # 1583

	# # lex_cantonese
	lex_cantonese_feature_path = feature_base + 'lex_cantonese'
	lex_cantonese_feats_all, filenames3 = load_COVFEFE_feats(lex_cantonese_feature_path)
	print('lex_cantonese feats dimension:', lex_cantonese_feats_all.shape) # 113

	# # matlab
	matlab_feature_path = feature_base + 'matlab_acoustics'
	matlab_feats_all, filenames4 = load_COVFEFE_feats(matlab_feature_path, ext='.txt')
	pause_feats_all = matlab_feats_all[:, 2:32]
	acoustic_feats_all = np.concatenate(([matlab_feats_all[:, 0:2], matlab_feats_all[:, 32:]]), axis=1)
	print('matlab feats dimension:', matlab_feats_all.shape)  # 60

	# # ELECTRA
	ELECTRA_feature_path = feature_base + 'ELECTRA_base'
	ELECTRA_feats_all, filenames5 = load_COVFEFE_feats(ELECTRA_feature_path)
	print('ELECTRA feats dimension:', ELECTRA_feats_all.shape) # 768

	# # ComparE
	# ComparE_feature_path = feature_base + 'ComparE'
	# ComparE_feats_all, filenames6 = load_COVFEFE_feats(ComparE_feature_path)
	# print('ComparE feats dimension:', ComparE_feats_all.shape)

	# # Emobase
	# Emobase_feature_path = feature_base + 'Emobase'
	# Emobase_feats_all, filenames7 = load_COVFEFE_feats(Emobase_feature_path)
	# print('Emobase feats dimension:', Emobase_feats_all.shape)

	# # # GeMAPS
	# GeMAPS_feature_path = feature_base + 'GeMAPS'
	# GeMAPS_feats_all, filenames8 = load_COVFEFE_feats(GeMAPS_feature_path)
	# print('GeMAPS feats dimension:', GeMAPS_feats_all.shape)  #63

	# # praat_syllable_nuclei
	# praat_syllable_nuclei_feature_path = feature_base + 'praat_syllable_nuclei'
	# praat_syllable_nuclei_feats_all, filenames9 = load_COVFEFE_feats(praat_syllable_nuclei_feature_path)
	# print('praat_syllable_nuclei feats dimension:', praat_syllable_nuclei_feats_all.shape) # 7


	# # # # eGeMAPS
	# eGeMAPS_feature_path = feature_base + 'eGeMAPS'
	# eGeMAPS_feats_all, filenames10 = load_COVFEFE_feats(eGeMAPS_feature_path)
	# print('eGeMAPS feats dimension:', eGeMAPS_feats_all.shape) # eGeMAPS

	###
	# filenames1_ = [file.split('/')[-1].split('.')[0] for file in filenames1]
	# filenames2_ = [file.split('/')[-1].split('.')[0] for file in filenames2]
	# filenames3_ = [file.split('/')[-1].split('.')[0] for file in filenames3]
	# filenames4_ = [file.split('/')[-1].split('.')[0] for file in filenames4]
	# filenames5_ = [file.split('/')[-1].split('.')[0] for file in filenames5]
	# filenames6_ = [file.split('/')[-1].split('.')[0] for file in filenames6]
	# filenames7_ = [file.split('/')[-1].split('.')[0] for file in filenames7]
	# filenames8_ = [file.split('/')[-1].split('.')[0] for file in filenames8]
	# filenames9_ = [file.split('/')[-1].split('.')[0] for file in filenames9]
	# filenames10_ = [file.split('/')[-1].split('.')[0] for file in filenames10]
	#
	# assert filenames1_ == filenames2_ == filenames3_ == filenames4_ == filenames5_ == filenames6_ == filenames7_ == filenames8_ == filenames9_ == filenames10_
	# filenames = filenames1_

	###
	filenames1_ = [file.split('/')[-1].split('.')[0] for file in filenames1]
	filenames2_ = [file.split('/')[-1].split('.')[0] for file in filenames2]
	filenames3_ = [file.split('/')[-1].split('.')[0] for file in filenames3]
	filenames4_ = [file.split('/')[-1].split('.')[0] for file in filenames4]
	assert filenames1_ == filenames2_ == filenames3_ == filenames4_
	filenames = filenames1_

	###
	# filenames = [file.split('/')[-1].split('.')[0] for file in filenames10]

	# labels and id
	all_labels = np.array(all_infor['Labels'])
	all_filename = np.array(all_infor['FileName'])
	all_id = np.array(all_infor['ID'])
	labels = np.array([all_labels[np.where(filename + '.wav' == all_filename)[0]][0] for filename in filenames])
	subject_id = np.array([all_id[np.where(filename + '.wav' == all_filename)[0]][0] for filename in filenames])

	# two class classification
	labels[np.where(labels == 2)[0]] = 1
	labels[np.where(labels == 3)[0]] = 1

	###
	trn_feats = np.concatenate(([lex_cantonese_feats_all,
								 ELECTRA_feats_all,
								 is10_feats_all,
								 COVAREP_feats_all,
								 matlab_feats_all]), axis=1)

	###
	# trn_feats = np.concatenate(([COVAREP_feats_all,
	# 							 is10_feats_all,
	# 							 lex_cantonese_feats_all,
	# 							 matlab_feats_all,
	# 							 ELECTRA_feats_all,
	# 							 ComparE_feats_all,
	# 							 Emobase_feats_all,
	# 							 GeMAPS_feats_all,
	# 							 praat_syllable_nuclei_feats_all,
	# 							 eGeMAPS_feats_all]), axis=1)

	# np.save('jccocc_features_1_10.npy', trn_feats)
	# np.save('jccocc_features_1_10_labels.npy', labels)
	# np.save('jccocc_features_1_10_subject_id.npy', subject_id)
	# print('Done!')

	###
	# trn_feats = np.concatenate(([ELECTRA_feats_all,
	# 							 eGeMAPS_feats_all]), axis=1)

	# trn_feats = eGeMAPS_feats_all
	trn_labels = labels
	tst_feats = []
	tst_labels = []
	subject_id = subject_id
	tst_subject_id = []

	return trn_feats, trn_labels, tst_feats, tst_labels, subject_id, tst_subject_id
	# return trn_feats[index_used, :], trn_labels[index_used], tst_feats, tst_labels, subject_id[index_used], tst_subject_id


def load_jccocc_moca_data_2022_03_19():

	def find_files(path, ext="", prefix=""):
		return [os.path.join(path, x) for x in os.listdir(path) if x.endswith(ext) and x.startswith(prefix)]

	def load_COVFEFE_feats(file_path, ext='.csv'):

		files = find_files(file_path, ext=ext)
		files.sort()
		features_all = []

		if np.array(pd.read_csv(files[0], ';')).shape[1] > np.array(pd.read_csv(files[0], ',')).shape[1]:
			sep = ';'
		else:
			sep = ','
		for file in files:
			temp = np.array(pd.read_csv(file, sep=sep))
			features_all.append(temp.flatten())
		try:
			features_all = np.array(features_all).astype(np.float)
		except:
			features_all = np.array(features_all)[:, 1:].astype(np.float)

		return features_all, files

	feature_base = '/home11a/xiaoquan/learning/features/JCCOCC_MOCA_2022_03_19/run2/'
	#
	# # matlab
	# matlab_feature_path = feature_base + 'matlab_acoustics'
	# matlab_feats_all, filenames_matlab = load_COVFEFE_feats(matlab_feature_path, ext='.txt')
	# acoustic_feats_all = np.concatenate(([matlab_feats_all[:, 0:2], matlab_feats_all[:, 32:]]), axis=1)
	# print('acoustic feats dimension:', acoustic_feats_all.shape)
	#
	# # # # # COVAREP
	# COVAREP_feature_path = feature_base + 'COVAREP'
	# COVAREP_feats_all, filenames_COVAREP = load_COVFEFE_feats(COVAREP_feature_path)
	# print('COVAREP feats dimension:', COVAREP_feats_all.shape)  # 518
	# #
	# # # # # # IS10
	# is10_feature_path = feature_base + 'is10'
	# is10_feats_all, IS10_filenames = load_COVFEFE_feats(is10_feature_path)
	# is10_feats_all = is10_feats_all[:, 1:]
	# print('IS10 feats dimension:', is10_feats_all.shape)  # 1582
	#
	# # ComparE
	# # ComparE_feature_path = feature_base + 'ComparE'
	# # ComparE_feats_all, ComparE_filenames = load_COVFEFE_feats(ComparE_feature_path)
	# # ComparE_feats_all = ComparE_feats_all[:, 1:]
	# # print('ComparE feats dimension:', ComparE_feats_all.shape)  # 6373
	#
	# # # # # # Emobase
	# Emobase_feature_path = feature_base + 'Emobase'
	# Emobase_feats_all, Emobase_filenames = load_COVFEFE_feats(Emobase_feature_path)
	# Emobase_feats_all = Emobase_feats_all[:, 1:]
	# print('Emobase feats dimension:', Emobase_feats_all.shape)  # 988
	# #
	# # # # # # GeMAPS
	# GeMAPS_feature_path = feature_base + 'GeMAPS'
	# GeMAPS_feats_all, GeMAPS_filenames = load_COVFEFE_feats(GeMAPS_feature_path)
	# GeMAPS_feats_all = GeMAPS_feats_all[:, 1:]
	# print('GeMAPS feats dimension:', GeMAPS_feats_all.shape)  # 62
	# #
	# # # # # eGeMAPS
	# eGeMAPS_feature_path = feature_base + 'eGeMAPS'
	# eGeMAPS_feats_all, eGeMAPS_filenames = load_COVFEFE_feats(eGeMAPS_feature_path)
	# eGeMAPS_feats_all = eGeMAPS_feats_all[:, 1:]
	# print('eGeMAPS feats dimension:', eGeMAPS_feats_all.shape)  # 62
	# #
	# # # # # # ELECTRA
	# ELECTRA_feature_path = feature_base + 'ELECTRA_base'
	# ELECTRA_feats_all, filenames_ELECTRA = load_COVFEFE_feats(ELECTRA_feature_path)
	# print('ELECTRA feats dimension:', ELECTRA_feats_all.shape)  #768
	# #
	# # # # # lex
	# lex_feature_path = feature_base + 'lex_cantonese'
	# lex_feats_all, filenames_lex = load_COVFEFE_feats(lex_feature_path)
	# print('lex feats dimension:', lex_feats_all.shape)
	# #
	# # # # # bert_cantonese
	# # # BERT_feature_path = feature_base + 'BERT'
	# # # BERT_feats_all, filenames6 = load_COVFEFE_feats(BERT_feature_path)
	# # # print('BERT feats dimension:', BERT_feats_all.shape) # 768
	# #
	# # # # # pause from .eaf files
	# pause_feature_path = feature_base + 'pause'
	# pause_feats_all, filenames_pause = load_COVFEFE_feats(pause_feature_path)
	# print('pause feats dimension:', pause_feats_all.shape) # 30
	#
	# # subject id, labels, ...
	# all_infor = pd.read_excel('/home11a/xiaoquan/learning/features/JCCOCC_MOCA_2022_03_19/CUHK-JCCOCC-MoCA-Labels.xlsx')
	# all_labels = np.array(all_infor['Labels'])
	# all_filename = np.array(all_infor['FileName'])
	# all_id = np.array(all_infor['ID'])
	#
	# filename__ = eGeMAPS_filenames
	# temp = np.array([name.split('/')[-1].split('.')[0].split('_')[0] + '.wav' for name in filename__])
	#
	# labels = np.array([all_labels[np.where(tmp == all_filename)[0]][0] for tmp in temp])
	# subject_id = np.array([all_id[np.where(tmp == all_filename)[0]][0] for tmp in temp])

	# # two class classification
	# labels[np.where(labels == 2)[0]] = 1
	# labels[np.where(labels == 3)[0]] = 1
	# #
	# trn_feats = eGeMAPS_feats_all
	# trn_feats = np.concatenate([lex_feats_all, ELECTRA_feats_all, pause_feats_all,
	# 							Emobase_feats_all, eGeMAPS_feats_all, acoustic_feats_all, COVAREP_feats_all,
	# 							is10_feats_all], axis=1)
	# #
	# # #
	# # np.save('jccocc_2022_03_19_features.npy', trn_feats)
	# # np.save('jccocc_2022_03_19_labels.npy', labels)
	# # np.save('jccocc_2022_03_19_subject_id.npy', subject_id)
	# # print('Done!')

	############### All features
	# trn_feats = np.load('jccocc_2022_03_19_features.npy')
	# labels = np.load('jccocc_2022_03_19_labels.npy')
	# subject_id = np.load('jccocc_2022_03_19_subject_id.npy')
	#
	# print('feature dimension:', trn_feats.shape)
	#
	# trn_labels = labels
	# tst_feats = []
	# tst_labels = []
	# subject_id = subject_id
	# tst_subject_id = []

	# ################ run1
	# def my_split(all_feats, all_labels, all_subject_id, label, random_state):
	#
	# 	pos_subject_id_unique = np.unique(all_subject_id[np.where(all_labels == label)[0]])
	# 	pos_subject_id_unique_train, pos_subject_id_unique_test = train_test_split(
	# 		pos_subject_id_unique, test_size=15, random_state=random_state)
	#
	# 	assert len(np.unique(np.concatenate((pos_subject_id_unique_train, pos_subject_id_unique_test)))) == \
	# 		   len(pos_subject_id_unique)
	#
	# 	pos_index_trn = np.concatenate([np.where(id == all_subject_id)[0] for id in pos_subject_id_unique_train])
	# 	pos_index_tst = np.concatenate([np.where(id == all_subject_id)[0] for id in pos_subject_id_unique_test])
	# 	pos_feats_trn = all_feats[pos_index_trn, :]
	# 	pos_feats_tst = all_feats[pos_index_tst, :]
	# 	pos_labels_trn = all_labels[pos_index_trn]
	# 	pos_labels_tst = all_labels[pos_index_tst]
	# 	pos_subject_id_trn = all_subject_id[pos_index_trn]
	# 	pos_subject_id_tst = all_subject_id[pos_index_tst]
	#
	# 	return pos_feats_trn, pos_feats_tst, pos_labels_trn, pos_labels_tst, pos_subject_id_trn, pos_subject_id_tst
	#
	# all_feats = np.load('jccocc_2022_03_19_features.npy')
	# all_labels = np.load('jccocc_2022_03_19_labels.npy')
	# all_subject_id = np.load('jccocc_2022_03_19_subject_id.npy')
	#
	# random_state = 1
	# # positive
	# pos_feats_trn, pos_feats_tst, pos_labels_trn, pos_labels_tst, pos_subject_id_trn, pos_subject_id_tst = my_split(
	# 	all_feats, all_labels, all_subject_id, 1, random_state)
	#
	# # negative
	# neg_feats_trn, neg_feats_tst, neg_labels_trn, neg_labels_tst, neg_subject_id_trn, neg_subject_id_tst = my_split(
	# 	all_feats, all_labels, all_subject_id, 0, random_state)
	#
	# ### train
	# trn_feats = np.concatenate((pos_feats_trn, neg_feats_trn), axis=0)
	# trn_labels = np.concatenate((pos_labels_trn, neg_labels_trn))
	# subject_id = np.concatenate((pos_subject_id_trn, neg_subject_id_trn))
	#
	# ### test
	# tst_feats = np.concatenate((pos_feats_tst, neg_feats_tst), axis=0)
	# tst_labels = np.concatenate((pos_labels_tst, neg_labels_tst))
	# tst_subject_id = np.concatenate((pos_subject_id_tst, neg_subject_id_tst))
	#
	# assert trn_feats.shape[0] == trn_labels.shape[0] == subject_id.shape[0]
	# assert tst_feats.shape[0] == tst_labels.shape[0] == tst_subject_id.shape[0]
	#
	# print('trn feature dimension:', trn_feats.shape)
	# print('tst feature dimension:', tst_feats.shape)

	################ run2, test set have (10+10)*3 =60 samples, randomstate=0
	def my_split(all_feats, all_labels, all_subject_id, label, random_state):

		pos_subject_id_unique = np.unique(all_subject_id[np.where(all_labels == label)[0]])
		pos_subject_id_unique_train, pos_subject_id_unique_test = train_test_split(
			pos_subject_id_unique, test_size=10, random_state=random_state)

		assert len(np.unique(np.concatenate((pos_subject_id_unique_train, pos_subject_id_unique_test)))) == \
			   len(pos_subject_id_unique)

		pos_index_trn = np.concatenate([np.where(id == all_subject_id)[0] for id in pos_subject_id_unique_train])
		pos_index_tst = np.concatenate([np.where(id == all_subject_id)[0] for id in pos_subject_id_unique_test])
		pos_feats_trn = all_feats[pos_index_trn, :]
		pos_feats_tst = all_feats[pos_index_tst, :]
		pos_labels_trn = all_labels[pos_index_trn]
		pos_labels_tst = all_labels[pos_index_tst]
		pos_subject_id_trn = all_subject_id[pos_index_trn]
		pos_subject_id_tst = all_subject_id[pos_index_tst]

		return pos_feats_trn, pos_feats_tst, pos_labels_trn, pos_labels_tst, pos_subject_id_trn, pos_subject_id_tst

	all_feats = np.load('jccocc_2022_03_19_features.npy')
	all_labels = np.load('jccocc_2022_03_19_labels.npy')
	all_subject_id = np.load('jccocc_2022_03_19_subject_id.npy')

	random_state = 0
	# positive
	pos_feats_trn, pos_feats_tst, pos_labels_trn, pos_labels_tst, pos_subject_id_trn, pos_subject_id_tst = my_split(
		all_feats, all_labels, all_subject_id, 1, random_state)

	# negative
	neg_feats_trn, neg_feats_tst, neg_labels_trn, neg_labels_tst, neg_subject_id_trn, neg_subject_id_tst = my_split(
		all_feats, all_labels, all_subject_id, 0, random_state)

	### train
	trn_feats = np.concatenate((pos_feats_trn, neg_feats_trn), axis=0)
	trn_labels = np.concatenate((pos_labels_trn, neg_labels_trn))
	subject_id = np.concatenate((pos_subject_id_trn, neg_subject_id_trn))

	### test
	tst_feats = np.concatenate((pos_feats_tst, neg_feats_tst), axis=0)
	tst_labels = np.concatenate((pos_labels_tst, neg_labels_tst))
	tst_subject_id = np.concatenate((pos_subject_id_tst, neg_subject_id_tst))

	assert trn_feats.shape[0] == trn_labels.shape[0] == subject_id.shape[0]
	assert tst_feats.shape[0] == tst_labels.shape[0] == tst_subject_id.shape[0]

	print('trn feature dimension:', trn_feats.shape)
	print('tst feature dimension:', tst_feats.shape)

	return trn_feats, trn_labels, tst_feats, tst_labels, subject_id, tst_subject_id


def load_sythetic_data(num_trn_samples, num_tst_samples, datatype):

	def generate_data(n=100, datatype='', seed=0):
		"""
        Generate data (X,y)
        Args:
            n(int): number of samples
            datatype(string): The type of data
            choices: 'orange_skin', 'XOR', 'regression'.
            seed: random seed used
        Return:
            X(float): [n,d].
            y(float): n dimensional array.
        """
		np.random.seed(seed)

		if datatype == 'binary_classification':
			X = []

			i = 0
			while i < n // 2:
				x = np.random.randn(10)
				if 9 < sum(x[:4] ** 2) < 16:
					X.append(x)
					i += 1
			X = np.array(X)

			X = np.concatenate((X, np.random.randn(n // 2, 10)))

			y = np.concatenate((-np.ones(n // 2), np.ones(n // 2)))

			perm_inds = np.random.permutation(n)
			X, y = X[perm_inds], y[perm_inds]

		elif datatype == 'XOR':
			X = np.random.randn(n, 10)
			y = np.zeros(n)
			splits = np.linspace(0, n, num=8 + 1, dtype=int)
			signals = [[1, 1, 1], [-1, -1, -1], [1, 1, -1], [-1, -1, 1], [1, -1, -1], [-1, 1, 1], [-1, 1, -1],
					   [1, -1, 1]]
			for i in range(8):
				X[splits[i]:splits[i + 1], :3] += np.array([signals[i]])
				y[splits[i]:splits[i + 1]] = i // 2

			perm_inds = np.random.permutation(n)
			X, y = X[perm_inds], y[perm_inds]

		return X, y

	trn_feats, trn_labels = generate_data(n=num_trn_samples, datatype=datatype, seed=1234)
	tst_feats, tst_labels = generate_data(n=num_tst_samples, datatype=datatype, seed=4321)

	trn_labels[np.where(trn_labels==-1)]=0
	tst_labels[np.where(tst_labels==-1)]=0

	return trn_feats, trn_labels, tst_feats, tst_labels, [], []


def load_glass_dataset(file_base_path):

	temp = pd.read_csv(file_base_path + 'glass.data', sep=',', header=None, index_col=0)
	features = temp.values[:, 0:-1]
	labels = (temp.values[:, -1] - 1).astype(np.int64)
	labels[np.where(labels == 4)] = 3
	labels[np.where(labels == 5)] = 4
	labels[np.where(labels == 6)] = 5

	return features, labels

def load_vowel_dataset(file_base_path):

	df = pd.read_csv(file_base_path + 'vowel-context.data', sep=' ', header=None)
	features = df.values[:, 3:13].astype(np.float)
	labels = df.values[:, -1]
	labels[np.isnan(labels)] = 10
	labels = labels.astype(np.int)

	return features, labels

def load_ALLAML_dataset(file_base_path):

	temp = scipy.io.loadmat(file_base_path + 'ALLAML.mat')
	trn_feats = temp['X']
	trn_labels = (temp['Y'].flatten() - 1).astype(np.int64)

	return trn_feats, trn_labels

def load_TOX_171_dataset(file_base_path):

	temp = scipy.io.loadmat(file_base_path + 'TOX-171.mat')
	trn_feats = temp['X']
	trn_labels = (temp['Y'].flatten() - 1).astype(np.int64)

	return trn_feats, trn_labels

def load_wine_dataset(file_base_path):

	temp = pd.read_csv(file_base_path + 'wine.data', sep=',', header=None)
	feats = temp.values[:, 1:].astype(np.float)
	labels = (temp.values[:, 0] -1).astype(np.int)

	return feats, labels

def load_Yale_dataset(file_base_path):

	temp = scipy.io.loadmat(file_base_path + 'Yale.mat')
	feats = temp['X'].astype(np.float)
	labels = (temp['Y'].flatten() - 1).astype(np.int64)

	return feats, labels

def load_mnist_dataset(file_base_path):

	from torchvision import datasets, transforms
	data_train = datasets.MNIST(root=file_base_path,
								transform=transforms,
								train=True,
								download=False)

	labels_all = np.array(data_train.targets)
	labels_3_index = np.where(labels_all == 3)[0]
	labels_8_index = np.where(labels_all == 8)[0]

	feats_all = np.array(data_train.data).reshape(-1, 784)
	feats_3 = feats_all[labels_3_index, :]
	feats_8 = feats_all[labels_8_index, :]

	feats = np.concatenate((feats_3, feats_8), axis=0).astype(np.float) / 255
	labels = np.concatenate((np.zeros(shape=feats_3.shape[0]), np.ones(shape=feats_8.shape[0])), axis=0).astype(np.int)

	return feats, labels

def load_benchmark_dataset(dataset):

	if dataset == 'glass':
		file_base_path = '/home11a/xiaoquan/learning/corpus/glass/'
		features, labels = load_glass_dataset(file_base_path)

	if dataset == 'vowel':
		file_base_path = '/home11a/xiaoquan/learning/corpus/benchmark/vowel/'
		features, labels = load_vowel_dataset(file_base_path)

	if dataset == 'ALLAML':
		file_base_path = '/home11a/xiaoquan/learning/corpus/benchmark/'
		features, labels = load_ALLAML_dataset(file_base_path)

	if dataset == 'TOX_171':
		file_base_path = '/home11a/xiaoquan/learning/corpus/benchmark/'
		features, labels = load_TOX_171_dataset(file_base_path)

	if dataset == 'wine':
		file_base_path = '/home11a/xiaoquan/learning/corpus/benchmark/wine/'
		features, labels = load_wine_dataset(file_base_path)

	if dataset == 'Yale':
		file_base_path = '/home11a/xiaoquan/learning/corpus/benchmark/'
		features, labels = load_Yale_dataset(file_base_path)

	return features, labels

def load_GM12878_dataset(file_base_path):

	data_df = pd.read_csv(file_base_path + 'GM12878_200bp_Data.txt', sep='	', header=None)
	label_df = pd.read_csv(file_base_path + 'GM12878_200bp_Classes.txt', header=None)

	feats_all = data_df.values
	labels_all = label_df.values.flatten()

	labels_A_E_index = np.where(labels_all == 'A-E')[0]
	labels_A_P_index = np.where(labels_all == 'A-P')[0]

	labels_I_E_index = np.where(labels_all == 'I-E')[0]
	labels_I_P_index = np.where(labels_all == 'I-P')[0]
	labels_A_X_index = np.where(labels_all == 'A-X')[0]
	labels_UK_index = np.where(labels_all == 'UK')[0]

	feats_A_E = feats_all[labels_A_E_index, :]
	feats_A_P = feats_all[labels_A_P_index, :]
	feats_BK = np.concatenate((feats_all[labels_I_E_index, :], feats_all[labels_I_P_index, :], feats_all[labels_A_X_index, :], feats_all[labels_UK_index, :]), axis=0)

	feats_A_P = np.array(pd.DataFrame(feats_A_P).sample(n=2878, replace=False, random_state=0, axis=0))
	feats_BK = np.array(pd.DataFrame(feats_BK).sample(n=2878, replace=False, random_state=0, axis=0))

	feats = np.log(np.concatenate((feats_A_E, feats_A_P, feats_BK), axis=0) + 0.01).astype(np.float)
	labels = np.concatenate((np.zeros(shape=(2878,)), np.ones(shape=(2878,)), np.ones(shape=(2878,))*2), axis=0).astype(np.int)

	return feats, labels

def load_support2_dataset(file_base_path):

	x = pd.read_csv(file_base_path + 'x_new.csv').values
	y = pd.read_csv(file_base_path + 'y_new.csv').values.ravel()
	x = x.astype(np.float32)
	y = y.astype(np.int64)

	return x, y

def load_MiniBooNE_dataset(file_base_path):

	df = pd.read_csv(file_base_path + 'MiniBooNE_PID.txt', header=None)
	feats_all = np.array(df.values).flatten()
	feats = np.array([np.array([float(item) for item in list(filter(None, feats_all[i].split(' ')))]) for i in range(len(feats_all))])

	feats_positive = np.array(pd.DataFrame(feats[0:36400, :]).sample(n=5000, replace=False, random_state=0, axis=0))
	feats_negative = np.array(pd.DataFrame(feats[36600:, :]).sample(n=5000, replace=False, random_state=0, axis=0))

	features = np.concatenate((feats_positive, feats_negative), axis=0).astype(np.float)
	labels = np.concatenate((np.ones(shape=(5000,)), np.zeros(shape=(5000,))), axis=0).astype(np.int)

	return features, labels

def load_realworld_dataset(dataset):

	if dataset == 'mnist':
		file_base_path = '/home11a/xiaoquan/learning/corpus/benchmark/'
		features, labels = load_mnist_dataset(file_base_path)

	if dataset == 'GM12878':
		file_base_path = '/home11a/xiaoquan/learning/corpus/GM12878/'
		features, labels = load_GM12878_dataset(file_base_path)

	if dataset == 'support2':
		file_base_path = '/home11a/xiaoquan/learning/corpus/support2/'
		features, labels = load_support2_dataset(file_base_path)

	if dataset == 'MiniBooNE':
		file_base_path = '/home11a/xiaoquan/learning/corpus/MiniBooNE/'
		features, labels = load_MiniBooNE_dataset(file_base_path)

	return features, labels, [], [], [], []

def load_feature_selection_repository(data):

	import scipy
	_ = []

	def load_features(data):
		feature_base = '/home11a/xiaoquan/learning/features/feature_selection_repository/'
		temp = scipy.io.loadmat(feature_base + data)
		trn_features = temp['X']
		trn_labels = (temp['Y'].squeeze() - 1).astype(np.int64)
		return trn_features, trn_labels

	if data == 'ALLAML':
		trn_features, trn_labels = load_features('ALLAML.mat')

	if data == 'BASEHOCK':
		trn_features, trn_labels = load_features('BASEHOCK.mat')

	if data == 'GLI_85':
		trn_features, trn_labels = load_features('GLI-85.mat')

	if data == 'GLIOMA':
		trn_features, trn_labels = load_features('GLIOMA.mat')

	if data == 'ISOLET':
		trn_features, trn_labels = load_features('Isolet.mat')

	if data == 'LEUKEMIA':
		trn_features, trn_labels = load_features('leukemia.mat')
		trn_labels[np.where(trn_labels == 0)[0]] = 1
		trn_labels[np.where(trn_labels == -2)[0]] = 0

	if data == 'LUNG_DISCRETE':
		trn_features, trn_labels = load_features('lung_small.mat') # 7

	if data == 'LUNG':
		trn_features, trn_labels = load_features('lung.mat') # 5

	if data == 'ORL':
		trn_features, trn_labels = load_features('ORL.mat')

	if data == 'RELATHE':
		trn_features, trn_labels = load_features('RELATHE.mat')

	if data == 'USPS':
		trn_features, trn_labels = load_features('USPS.mat')

	if data == 'WARPAR10P':
		trn_features, trn_labels = load_features('warpAR10P.mat')

	if data == 'WARPPIE10P':
		trn_features, trn_labels = load_features('warpPIE10P.mat')

	if data == 'GISETTE':
		trn_features, trn_labels = load_features('gisette.mat')
		trn_labels[np.where(trn_labels == 0)[0]] = 1
		trn_labels[np.where(trn_labels == -2)[0]] = 0

	if data == 'PROSTATE_GE':
		trn_features, trn_labels = load_features('Prostate-GE.mat')

	if data == 'PCMAC':
		trn_features, trn_labels = load_features('PCMAC.mat')

	if data == 'glass':
		file_base_path = '/home11a/xiaoquan/learning/corpus/glass/'
		trn_features, trn_labels = load_glass_dataset(file_base_path)

	if data == 'vowel':
		file_base_path = '/home11a/xiaoquan/learning/corpus/benchmark/vowel/'
		trn_features, trn_labels = load_vowel_dataset(file_base_path)

	if data == 'TOX_171':
		file_base_path = '/home11a/xiaoquan/learning/corpus/benchmark/'
		trn_features, trn_labels = load_TOX_171_dataset(file_base_path)

	if data == 'Yale':
		file_base_path = '/home11a/xiaoquan/learning/corpus/benchmark/'
		trn_features, trn_labels = load_Yale_dataset(file_base_path)

	assert trn_features.shape[0] == trn_labels.shape[0]
	labels_unique = np.unique(trn_labels)
	return trn_features, trn_labels, _, _ , _, _
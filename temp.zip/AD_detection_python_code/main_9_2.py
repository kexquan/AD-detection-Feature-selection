import os
import pdb

import numpy as np
from itertools import repeat

from sklearn.model_selection import KFold
from sklearn.model_selection import ParameterGrid
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from sklearn.metrics import balanced_accuracy_score

import torch
from torch.multiprocessing import Pool
import multiprocessing as mp

from dataLoader import load_AD2021_train_data
from dataLoader import load_ADReSS2020_train_data
from dataLoader import load_jccocc_moca_data
from dataLoader import load_feature_selection_repository
from dataLoader import load_sythetic_data
from dataLoader import load_jccocc_moca_data_2022_03_19

from sklearn.utils import shuffle
import warnings
warnings.filterwarnings('ignore')

def Standardize(X_train, X_test):
    std = StandardScaler().fit(X_train)
    X_train = std.transform(X_train)
    X_test = std.transform(X_test)
    return X_train, X_test

def inner_cross_validation(X, y, cv_inner, method, num_fs, para, random_state):
    acc_all=[]
    for train_ix, test_ix in cv_inner.split(X):
        X_train, X_test = X[train_ix, :], X[test_ix, :]
        y_train, y_test = y[train_ix], y[test_ix]
        X_train, X_test = Standardize(X_train, X_test)
        index_selected, importances = feature_selection(X_train, y_train, method, num_fs, para, random_state)
        acc_ = [classification(X_train[:, index], y_train, X_test[:, index], y_test) for index in index_selected]
        acc_all.append(acc_)
    if num_fs==None:
        return np.array(acc_all).mean(axis=0).max(), list(range(1, X.shape[1] + 1))[np.argmax(np.array(acc_all).mean(axis=0))]
    else:
        return np.array(acc_all).mean(axis=0), num_fs

def outer_run(X, y, cv_inner, method, num_fs, parameters, random_state):

    if parameters==None:
        param_list = [None]
    else:
        param_list = list(ParameterGrid(parameters))

    accuracy_all=[]
    num_fs_all=[]
    for para in param_list:
        print('parameters:', para)
        accuracy, num_fs_ = inner_cross_validation(X, y, cv_inner, method, num_fs, para, random_state)
        accuracy_all.append(accuracy)
        num_fs_all.append(num_fs_)

    if num_fs == None:
        accuracy_all = np.array(accuracy_all)
        index_max = np.argmax(accuracy_all)
        best_parameter = param_list[index_max]
        return [best_parameter], [num_fs_all[index_max]]
    else:
        accuracy_all = np.array(accuracy_all)
        index_max = np.argmax(accuracy_all, axis=0)
        best_parameter=[param_list[index] for index in index_max]
        return best_parameter, num_fs_all[0]

def fun_(X, y, train_ix, test_ix, cv_inner, method, num_fs, all_parameters, random_state):

    X_train, X_test = X[train_ix, :], X[test_ix, :]
    y_train, y_test = y[train_ix], y[test_ix]

    if num_fs == None:

        best_parameter, num_fs = outer_run(X_train, y_train, cv_inner, method, num_fs, all_parameters, random_state)

        X_train, X_test = Standardize(X_train, X_test)
        acc_all = []
        index_selected_all = []
        importances_all = []

        for fs, para in zip(num_fs, best_parameter):
            index_selected, importances = feature_selection(X_train, y_train, method, [fs], para, random_state)
            acc = classification(X_train[:, index_selected[0]], y_train, X_test[:, index_selected[0]], y_test)
            acc_all.append(acc)
            index_selected_all.append(index_selected[0])
            importances_all.append(importances[0])

    elif all_parameters == None or len(list(ParameterGrid(all_parameters))) == 1:

        if all_parameters == None:
            best_parameter = None
        elif len(list(ParameterGrid(all_parameters))) == 1:
            best_parameter = ParameterGrid(all_parameters)[0]

        X_train, X_test = Standardize(X_train, X_test)
        acc_all = []
        index_selected_all = []
        importances_all = []

        index_selected_all_fs, importances = feature_selection(X_train, y_train, method, num_fs, best_parameter, random_state)
        for i in range(len(num_fs)):
            acc = classification(X_train[:, index_selected_all_fs[i]], y_train, X_test[:, index_selected_all_fs[i]], y_test)
            acc_all.append(acc)
            index_selected_all.append(index_selected_all_fs[i])
            importances_all.append(importances[i])

    elif len(list(ParameterGrid(all_parameters))) > 1:  #Need parameter fintuned

        best_parameter, num_fs = outer_run(X_train, y_train, cv_inner, method, num_fs, all_parameters, random_state)

        X_train, X_test = Standardize(X_train, X_test)
        acc_all = []
        index_selected_all = []
        importances_all = []

        for fs, para in zip(num_fs, best_parameter):
            index_selected, importances = feature_selection(X_train, y_train, method, [fs], para, random_state)
            acc = classification(X_train[:, index_selected[0]], y_train, X_test[:, index_selected[0]], y_test)
            acc_all.append(acc)
            index_selected_all.append(index_selected[0])
            importances_all.append(importances[0])

    return acc_all, index_selected_all, importances_all, best_parameter, num_fs

def nested_cross_validation(X, y, subject_id, cv_outer, cv_inner, method, num_fs, all_parameters, random_state, num_workers, consider_speaker):

    index_selected_all = []
    importances_all = []
    accuracy_all = []
    best_parameter_all = []
    num_fs_all = []

    if consider_speaker:
        subject_unique_id = np.unique(subject_id)
        id_list = np.array_split(shuffle(subject_unique_id, random_state=random_state), 10)
        train_index_all = []
        test_index_all = []
        for ids in id_list:
            test_index = np.concatenate([np.where(id == subject_id)[0] for id in ids])
            trn_index = np.delete(range(len(subject_id)), test_index)
            test_index_all.append(test_index)
            train_index_all.append(trn_index)
            assert len(np.unique(subject_id[test_index])) + len(np.unique(subject_id[trn_index])) == len(subject_unique_id)
    else:
        train_index_all = []
        test_index_all = []
        for train_index, test_index in cv_outer.split(X):
            train_index_all.append(train_index)
            test_index_all.append(test_index)

    args = list(zip(repeat(X), repeat(y), train_index_all, test_index_all,
                    repeat(cv_inner),
                    repeat(method), repeat(num_fs), repeat(all_parameters),
                    repeat(random_state)))

    if 'CCM' in method or 'DeepFIR' in method:
        num_workers = 1

    pool = Pool(num_workers)
    results = pool.starmap(fun_, args)
    for result in results:
        accuracy_all.append(result[0])
        index_selected_all.append(result[1])
        importances_all.append(result[2])
        best_parameter_all.append(result[3])
        num_fs_all.append(result[4])

    # for i in range(len(train_index_all)):
    #     fun_(X, y, train_index_all[i], test_index_all[i], cv_inner, method, num_fs, all_parameters, random_state)

    return accuracy_all, index_selected_all, importances_all, best_parameter_all, num_fs_all

################################################### begin
def classification(X_train, y_train, X_test, y_test):
    clf = classifier()
    clf.fit(X_train, y_train)
    pre_dict_label = clf.predict(X_test)
    return accuracy_score(y_test, pre_dict_label)

def classifier():
    return SVC(kernel='rbf', C=1, probability=True, gamma='auto', random_state=0)

from feature_selection_1 import feature_selection
if __name__ == '__main__':

    os.environ["CUDA_VISIBLE_DEVICES"] = "2"

    datasetfold = "jccocc_2022_03_19"

    consider_speaker = True

    datas = ['jccocc_45']

    # methods = ['NetAct_FIR', 'DFS', 'dropoutFR', 'DDR']
    # methods = ['DDR', 'NetAct_FIR', 'DFS', 'dropoutFR']
    # methods = [('two_stage', 'MutInfo', 'NetAct_FIR'),
    #            ('two_stage', 'MutInfo', 'DDR'),
    #            ('two_stage', 'MutInfo', 'DFS'),
    #            ('two_stage', 'MutInfo', 'dropoutFR')]
    methods = [('two_stage', 'MutInfo', 'DeepFIR')]

    num_fs = list(range(1, 2001))

    random_states = list(range(10))
    num_workers = 10
    num_outer_fold = 10

    torch.multiprocessing.set_start_method('spawn')

    for data in datas:

        print('Dataset:', data)

        if datasetfold == "AD2021_journal2":
            trn_feats_all, trn_labels_all, tst_feats_all, tst_labels_all, trn_subject_id, tst_subject_id = load_AD2021_train_data()
        elif datasetfold == "ADReSS_journal2":
            trn_feats_all, trn_labels_all, tst_feats_all, tst_labels_all, trn_subject_id, tst_subject_id = load_ADReSS2020_train_data()
        elif datasetfold == 'jccocc_moca':
            trn_feats_all, trn_labels_all, tst_feats_all, tst_labels_all, trn_subject_id, tst_subject_id = load_jccocc_moca_data()
        elif datasetfold == 'feature_selection_repository':
            trn_feats_all, trn_labels_all, tst_feats_all, tst_labels_all, trn_subject_id, tst_subject_id = load_feature_selection_repository(
                data)
        elif datasetfold == 'synthetic':
            trn_feats_all, trn_labels_all, tst_feats_all, tst_labels_all, trn_subject_id, tst_subject_id = load_sythetic_data(
                1024, 1024, data)
        elif datasetfold == 'jccocc_2022_03_19':
            trn_feats_all, trn_labels_all, tst_feats_all, tst_labels_all, trn_subject_id, tst_subject_id = load_jccocc_moca_data_2022_03_19()

        print('feature dimension:', trn_feats_all.shape)

        for random_state in random_states:
            print('Random_state:', random_state)
            for method in methods:

                if 'RF' == method:
                    parameters = {"n_estimators": list(range(100, 121)), "max_depth": list(range(10, 16))}
                    # parameters = {"n_estimators": list(range(100, 102)), "max_depth": list(range(10, 13))}
                elif ('RF' in method) or ('dropoutFR' in method) or ('DFS' in method):
                    parameters = {'reg_cof': [0.01], 'num_fs_left': [2000]}
                elif ('DeepFIR' in method) or ('NetAct_FIR' in method):
                    parameters = {'s': [250], 'num_fs_left': [2000]}
                else:
                    parameters = {'num_fs_left': [2000]}

                #######################################################
                print('Method:', method)
                cv_outer = KFold(n_splits=num_outer_fold, shuffle=True, random_state=random_state)
                cv_inner = KFold(n_splits=5, shuffle=True, random_state=random_state)
                accuracy, index_selected, importances, best_parameter, num_fs_ = nested_cross_validation(trn_feats_all,
                                                                                                         trn_labels_all,
                                                                                                         trn_subject_id,
                                                                                                         cv_outer,
                                                                                                         cv_inner,
                                                                                                         method, num_fs,
                                                                                                         parameters,
                                                                                                         random_state,
                                                                                                         num_workers,
                                                                                                         consider_speaker)
                save_path = 'results/' + datasetfold + '/' + data + '_' + '_'.join(method) + '_randomstate_' + str(
                    random_state)
                results = {'accuracy': accuracy, 'index_selected': index_selected, 'importances': importances,
                           'best_parameter': best_parameter, 'num_fs': num_fs_}
                np.savez(save_path, results)
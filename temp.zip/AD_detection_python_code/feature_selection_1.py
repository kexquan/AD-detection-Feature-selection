from scipy.stats import pearsonr
from sklearn.svm import LinearSVC
from sklearn.feature_selection import SelectFromModel
from sklearn.feature_selection import RFE
from sklearn.linear_model import Lasso
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import f_classif, mutual_info_classif
from sklearn.ensemble import RandomForestClassifier
import numpy as np
from sklearn.svm import SVC
import torch
import sys
import random
import pandas as pd
import os

from sklearn.linear_model import lars_path
from sklearn.feature_selection import SequentialFeatureSelector
from sklearn.feature_selection import RFE
from mrmr import mrmr_classif

def logit(x):
    return np.log(x) - np.log(1. - x)

def lasso_select_features(X_train, y_train, X_test, alpha=1.0):
    lasso = Lasso(alpha=alpha, max_iter=-1)     # use linear model: (1 / (2 * n_samples)) * ||y - Xw||^2_2 + alpha * ||w||_1
    lasso.fit(X_train, y_train)
    model = SelectFromModel(lasso, prefit=True)
    X_train = model.transform(X_train)
    X_test = model.transform(X_test)
    return X_train, X_test

def l1norm_select_features(X_train, y_train, X_test, penalty=0.01):
    lsvc = LinearSVC(C=penalty, penalty="l1", dual=False).fit(X_train, y_train) # use svm model: the regularization is also: alpha * ||w||_1
    model = SelectFromModel(lsvc, prefit=True)
    X_train = model.transform(X_train)
    X_test = model.transform(X_test)
    return X_train, X_test


def univ_select_features(X_train, y_train, X_test, n_fs):
    univ = SelectKBest(score_func=f_classif, k=n_fs)
    univ.fit(X_train, y_train)
    X_train = univ.transform(X_train)
    X_test = univ.transform(X_test)
    return X_train, X_test

def fdr_select_features(X_train, y_train, n_fs):
    fidx = []
    # n_classes = np.max(y_train) + 1

    fdr_all=[]
    n_classes = len(np.unique(y_train))
    for i in range(n_classes):
        X_p = X_train[y_train == i]
        X_n = X_train[y_train != i]
        mu_p = np.mean(X_p, axis=0)
        mu_n = np.mean(X_n, axis=0)
        sigma_p = np.std(X_p, axis=0)
        sigma_n = np.std(X_n, axis=0)
        fdr = ((mu_p - mu_n)**2)/(sigma_p**2 + sigma_n**2)
        fdr_all.append(fdr)
        idx = np.argsort(-1 * fdr)
        fidx.append(idx[0:n_fs])
    fidx = np.asarray(fidx).reshape((n_classes*n_fs, ))
    # fidx = np.unique(fidx)
    # return X_train[:, fidx], X_test[:, fidx]
    index_selected = np.array(pd.value_counts(fidx).index[0:n_fs])
    return X_train[:, index_selected], index_selected, np.array(fdr_all).mean(axis=0)

def rfe_select_features(X_train, y_train, X_test, n_fs, penalty=1, step=1):
    svc = SVC(kernel="linear", C=penalty)
    rfe = RFE(estimator=svc, n_features_to_select=n_fs, step=step)
    rfe.fit(X_train, y_train)
    mask = rfe.support_
    fidx = np.where(mask)[0].tolist()
    X_train = X_train[:, fidx]
    X_test = X_test[:, fidx]
    return X_train, X_test

def ANOVA_select_features(X_train, y_train, n_fs):

    sel_ = SelectKBest(f_classif, k=n_fs).fit(X_train, y_train)
    selected_index = sel_.get_support(indices=True)
    importances = sel_.scores_

    return X_train[:, selected_index], selected_index, importances

def NetAct_FIR_select_features(trn_feats, trn_labels, parameter, random_state):

    sys.path.append('/home11a/xiaoquan/learning/AD_detection/NetAct_FIR/')

    from FIR_main import NetAct_FIR_run
    from DataGenerator import get_one_hot

    def setup_seed(seed):
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        np.random.seed(seed)
        random.seed(seed)
        torch.backends.cudnn.deterministic = True

    torch.set_default_tensor_type(torch.cuda.DoubleTensor)
    setup_seed(random_state)

    s = parameter['s']
    s_p = round(s*0.4)
    # s_p = 10

    phase_2_start = 6000
    # operator_arch = [128, 32, len(np.unique(trn_labels))]
    # selector_arch = [128, 32, 1]
    operator_arch = [512, 128, 32, len(np.unique(trn_labels))]
    selector_arch = [512, 128, 32, 1]
    mask_batch_size = 32
    data_batch_size = 32

    trn_labels = get_one_hot(trn_labels.astype(np.int8), len(np.unique(trn_labels)))

    importances, optimal_masks = NetAct_FIR_run(trn_feats, trn_labels, phase_2_start, data_batch_size, mask_batch_size, s, s_p, operator_arch, selector_arch)

    return importances

def DDR_select_features(X_train, y_train, parameters, random_state):

    sys.path.append('/home11a/xiaoquan/learning/AD_detection/Dropout_FIR_torch/')
    from DDR_main import DDR_run
    def setup_seed(seed):
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        np.random.seed(seed)
        random.seed(seed)
        torch.backends.cudnn.deterministic = True

    # if 'initi_dropout_rate' in parameters:
    #     initi_dropout_rate = parameters['initi_dropout_rate']
    # else:
    initi_dropout_rate = 0.35

    operator_arch = [512, 128, 32, len(np.unique(y_train))]
    selector_arch = [512, 128, 32, 1]
    mask_batch_size = 32
    data_batch_size = 32

    torch.set_default_tensor_type(torch.cuda.DoubleTensor)
    setup_seed(random_state)
    preserve_logit_p = DDR_run(X_train, y_train, (X_train.shape[1],),
                           operator_arch, selector_arch,
                           data_batch_size, mask_batch_size,
                           initi_dropout_rate)

    return preserve_logit_p

def two_stage_feature_selection(X_train, y_train, method, parameters, random_state):

    num_fs_stage1 = parameters['num_fs_left']
    def get_nfs_top_rank_index(rank, nfs):
        def sigmoid(x):
            return 1 / (1 + np.exp(-x))
        preserver_rate = sigmoid(rank)  # rank = - logit_p <--> - dropout rate, sigmoid(rank) = preserver_rate
        rank_index = np.argsort(-preserver_rate)  # preserver_rate in descending order (xiajiang)
        return rank_index[0: nfs]

    # Stage1
    if method[1] == 'fdr':
        X_train, selected_index1, _ = fdr_select_features(X_train, y_train, num_fs_stage1)
    elif method[1] == 'ANOVA':
        X_train, selected_index1, _ = ANOVA_select_features(X_train, y_train, num_fs_stage1)
    elif method[1] == 'PeaCorr':
        X_train, selected_index1, _ = pearson_correlation_test(X_train, y_train, num_fs_stage1)
    elif method[1] == 'MutInfo':
        X_train, selected_index1, _ = mutual_info(X_train, y_train, num_fs_stage1)

    # Stage2
    if method[2] == 'DDR':
        preserve_logit_p = DDR_select_features(X_train, y_train, parameters, random_state)
    if method[2] == 'NetAct_FIR':
        preserve_logit_p = NetAct_FIR_select_features(X_train, y_train, parameters, random_state)
    if method[2] == 'DFS':
        _, preserve_logit_p = deep_feature_selection(X_train, y_train, parameters, random_state)
    if method[2] == 'dropoutFR':
        _, preserve_logit_p = dropoutFR_feature_selection(X_train, y_train, parameters, random_state)
    if method[2] == 'DeepFIR':
        preserve_logit_p = DeepFIR_feature_selection(X_train, y_train, parameters, random_state)
    if method[2] == 'RF':
        _, preserve_logit_p = random_forests_select_features(X_train, y_train, None)

    return selected_index1[get_nfs_top_rank_index(preserve_logit_p, num_fs_stage1)], preserve_logit_p

def lasso_path_select_features(trn_feats, trn_labels):

    def generate_lars_path(weighted_data, weighted_labels):

        x_vector = weighted_data
        alphas, active, coefs = lars_path(x_vector, weighted_labels, method='lasso', verbose=False)
        return alphas, active, coefs

    alphas, active, coefs = generate_lars_path(trn_feats, trn_labels)
    return active

def random_forests_select_features(trn_feats, trn_labels, parameter):

    '''
        Random Forest for Feature Selection
    '''

    if parameter == None:
        rf = RandomForestClassifier(random_state=0)
    else:
        rf = RandomForestClassifier(n_estimators=parameter["n_estimators"], max_depth=parameter["max_depth"], random_state=0)

    rf.fit(trn_feats, trn_labels)
    rf.feature_importances_.reshape(-1, 1)
    importances = rf.feature_importances_
    indices = np.argsort(importances)[::-1]

    return indices, importances

def sequential_feature_selection(trn_feats, trn_labels, fs, direction):

    clf = SVC(kernel="rbf", C=1, gamma='scale')
    selector = SequentialFeatureSelector(clf, n_features_to_select=fs, direction=direction).fit(trn_feats, trn_labels)
    return selector.get_support(indices=True)

def svm_ref_feature_selection(trn_feats, trn_labels, num_fs, step):
    estimator = SVC(kernel="linear", C=1, gamma='scale') # binary classification, XOR
    selector = RFE(estimator, n_features_to_select=num_fs, step=step)
    selector = selector.fit(trn_feats, trn_labels)
    return selector.get_support(indices=True)

def pearson_correlation_test(trn_feats, trn_labels, fs):
    name = ['feat_'+str(i) for i in range(trn_feats.shape[1])]
    name.append('target')
    name = np.array(name)
    data = np.concatenate((trn_feats, trn_labels.reshape(-1,1)), axis=1)
    df = pd.DataFrame(data, columns=name)
    pearson_corr_df = df.corr(method='pearson')
    pearson_corr_df = pearson_corr_df['target'].reset_index()
    pearson_corr_df.columns = ['STATISTIC', 'PEARSON_CORRELATION']
    pearson_corr_df['PEARSON_CORRELATION_ABS'] = abs(pearson_corr_df['PEARSON_CORRELATION'])
    importances = np.array(pearson_corr_df['PEARSON_CORRELATION_ABS'][:-1])
    index_selected = np.argsort(-importances)[0:fs]
    return trn_feats[:, index_selected], index_selected, importances

def mutual_info(trn_feats, trn_labels, fs):

    # sel_ = SelectKBest(mutual_info_classif, k=trn_feats.shape[1]).fit(trn_feats, trn_labels)
    # importances = sel_.scores_

    importances = mutual_info_classif(trn_feats, trn_labels, random_state=0)

    index_selected = np.argsort(-importances)[0:fs]
    return trn_feats[:, index_selected], index_selected, importances

def mRMR_select_features(trn_feats, trn_labels):
    selected_features = mrmr_classif(pd.DataFrame(trn_feats), pd.Series(trn_labels), K=trn_feats.shape[1])
    return selected_features

def CCM_select_features(trn_feats, trn_labels, num_fs):

    sys.path.append('/home11a/xiaoquan/learning/AD_detection/CCM/core')
    import ccm

    def set_memory(fra_):
        from tensorflow.python.keras.backend import set_session
        import tensorflow as tf
        config = tf.compat.v1.ConfigProto()
        config.gpu_options.per_process_gpu_memory_fraction = fra_
        set_session(tf.compat.v1.Session(config=config))

    set_memory(0.2)

    rank = ccm.ccm(trn_feats, trn_labels, num_fs, 'categorical', 0.001, iterations=100, verbose=False)
    rank = rank-1
    return rank

def deep_feature_selection(trn_feats, trn_labels, parameter, random_state):
    sys.path.append('/home11a/xiaoquan/learning/AD_detection/Dropout_FR/')
    sys.path.append('/home11a/xiaoquan/learning/AD_detection/Dropout_FR/exp/DFRdatasets')
    from mlp_predict import run_with_test_fold, parse_args
    from exp.DFRdatasets.dataloaders.LoaderBase import LoaderBase

    if 'reg_cof' in parameter:
        reg_cof = parameter['reg_cof']
    else:
        reg_cof = 0.01

    dimensions = [trn_feats.shape[1], 512, 128, 32, len(np.unique(trn_labels))]

    # torch.set_default_tensor_type(torch.cuda.DoubleTensor)
    args = parse_args(random_state)  # set random seed
    args.test_func = "no_test"
    args.identifier = "test"
    rank_name = 'dfs_rank'
    loader = LoaderBase.create(
        'other', {'visdom_enabled': args.visdom_enabled,
                  'cuda_enabled': args.cuda,
                  'nn_cache': args.nn_cache})

    _, rank = run_with_test_fold(trn_feats.astype(np.float32), trn_labels.astype(np.int64), rank_name, reg_cof, args,
                                 loader, dimensions)
    index_selected = np.argsort(-rank)
    return index_selected, rank

def dropoutFR_feature_selection(trn_feats, trn_labels, parameter, random_state):

    sys.path.append('/home11a/xiaoquan/learning/AD_detection/Dropout_FR/')
    sys.path.append('/home11a/xiaoquan/learning/AD_detection/Dropout_FR/exp/DFRdatasets')
    from mlp_predict import run_with_test_fold, parse_args
    from exp.DFRdatasets.dataloaders.LoaderBase import LoaderBase

    if 'reg_cof' in parameter:
        reg_cof = parameter['reg_cof']
    else:
        reg_cof = 0.01

    dimensions = [trn_feats.shape[1], 512, 128, 32, len(np.unique(trn_labels))]

    # torch.set_default_tensor_type(torch.cuda.DoubleTensor)
    args = parse_args(random_state)  # set random seed
    args.test_func = "no_test"
    args.identifier = "test"
    rank_name = 'nn_joint_rank'
    loader = LoaderBase.create(
        'other', {'visdom_enabled': args.visdom_enabled,
                  'cuda_enabled': args.cuda,
                  'nn_cache': args.nn_cache})

    _, rank = run_with_test_fold(trn_feats.astype(np.float32), trn_labels.astype(np.int64), rank_name, reg_cof, args,
                                 loader, dimensions)
    index_selected = np.argsort(-rank)
    return index_selected, rank

def Neural_dropoutFR0_feature_selection(trn_feats, trn_labels, parameter, random_state):

    sys.path.append('/home11a/xiaoquan/learning/AD_detection/Neural_DropoutFR0/')
    sys.path.append('/home11a/xiaoquan/learning/AD_detection/Neural_DropoutFR0/exp/DFRdatasets')
    from mlp_predict import run_with_test_fold, parse_args
    from exp.DFRdatasets.dataloaders.LoaderBase import LoaderBase

    if 'reg_cof' in parameter:
        reg_cof = parameter['reg_cof']
    else:
        reg_cof = 0.01

    dimensions = parameter['dimensions']

    torch.set_default_tensor_type(torch.cuda.DoubleTensor)
    args = parse_args(random_state) #set random seed
    args.test_func = "no_test"
    args.identifier = "test"
    rank_name = 'nn_joint_rank'
    loader = LoaderBase.create(
        'other', {'visdom_enabled': args.visdom_enabled,
                       'cuda_enabled': args.cuda,
                       'nn_cache': args.nn_cache})

    _, rank = run_with_test_fold(trn_feats.astype(np.float64), trn_labels.astype(np.int64), rank_name, reg_cof, args, loader, dimensions)
    return rank

def Neural_dropoutFR_feature_selection(trn_feats, trn_labels, parameter, random_state):

    sys.path.append('/home11a/xiaoquan/learning/AD_detection/Neural_DropoutFR/')
    sys.path.append('/home11a/xiaoquan/learning/AD_detection/Neural_DropoutFR/exp/DFRdatasets')
    from mlp_predict import run_with_test_fold, parse_args
    from exp.DFRdatasets.dataloaders.LoaderBase import LoaderBase

    if 'reg_cof' in parameter:
        reg_cof = parameter['reg_cof']
    else:
        reg_cof = 0.01

    dimensions = parameter['dimensions']

    torch.set_default_tensor_type(torch.cuda.DoubleTensor)
    args = parse_args(random_state) #set random seed
    args.test_func = "no_test"
    args.identifier = "test"
    rank_name = 'nn_joint_rank'
    loader = LoaderBase.create(
        'other', {'visdom_enabled': args.visdom_enabled,
                       'cuda_enabled': args.cuda,
                       'nn_cache': args.nn_cache})

    _, rank = run_with_test_fold(trn_feats.astype(np.float64), trn_labels.astype(np.int64), rank_name, reg_cof, args, loader, dimensions)
    return rank

def DeepFIR_feature_selection(trn_feats, trn_labels, parameter, random_state):

    sys.path.append('/home11a/xiaoquan/learning/AD_detection/FIR_DL/')

    from FIR_main import FIR_run
    from DataGenerator import get_one_hot
    import tensorflow as tf

    def seed_tensorflow(seed):
        random.seed(seed)
        os.environ['PYTHONHASHSEED'] = str(seed)
        np.random.seed(seed)
        tf.random.set_seed(seed)

    def set_memory(fra_):
        from tensorflow.python.keras.backend import set_session
        config = tf.compat.v1.ConfigProto()
        config.gpu_options.per_process_gpu_memory_fraction = fra_
        set_session(tf.compat.v1.Session(config=config))

    seed_tensorflow(random_state)
    set_memory(0.2)

    s = parameter['s']
    operator_arch = [512, 128, 32, len(np.unique(trn_labels))]
    selector_arch = [512, 128, 32, 1]
    mask_batch_size = 32
    data_batch_size = 32
    phase_2_start = 6000
    s_p = round(s*0.4)

    trn_labels = get_one_hot(trn_labels.astype(np.int8), len(np.unique(trn_labels)))

    importances = FIR_run(trn_feats, trn_labels, phase_2_start, data_batch_size, mask_batch_size, s, s_p, operator_arch, selector_arch)

    return importances

def feature_selection(trn_feats, trn_labels, method, num_fs, parameter, random_state):

    if num_fs == None:
        num_fs = list(range(1, trn_feats.shape[1] + 1))

    if method[0] == 'two_stage':
        index_selected, importance = two_stage_feature_selection(trn_feats, trn_labels, method, parameter, random_state)
        if num_fs == None:
            num_fs = list(range(1, parameter['num_fs_left'] + 1))
        index_selected_all = [np.array(index_selected[0:fs_]) for fs_ in num_fs]
        importances = [importance for fs_ in num_fs]
        return index_selected_all, importances

    elif method == 'lasso_path':
        active = lasso_path_select_features(trn_feats, trn_labels)
        index_selected_all = [np.array(active[0:fs_]) for fs_ in num_fs]
        importance = [[] for fs_ in num_fs]
        return index_selected_all, importance
    elif method == 'RF':
        indices, importances = random_forests_select_features(trn_feats, trn_labels, parameter)
        index_selected_all = [np.array(indices[0:fs_]) for fs_ in num_fs]
        importance_all = [importances for fs_ in num_fs]
        return index_selected_all, importance_all
    elif method == 'FS':
        index_selected_all = []
        for fs in num_fs:
            index_selected = sequential_feature_selection(trn_feats, trn_labels, fs, 'forward')
            index_selected_all.append(index_selected)
        importance = [[] for fs_ in num_fs]
        return index_selected_all, importance
    elif method == 'BS':
        index_selected_all = []
        for fs in num_fs:
            if fs == trn_feats.shape[1]:
                index_selected_all.append(np.array(range(trn_feats.shape[1])))
            else:
                index_selected = sequential_feature_selection(trn_feats, trn_labels, fs, 'backward')
                index_selected_all.append(index_selected)
        importance = [[] for fs_ in num_fs]
        return index_selected_all, importance
    elif method == 'RFE':
        index_selected_all = []
        step=1 # binary classification and XOR
        for fs in num_fs:
            index_selected = svm_ref_feature_selection(trn_feats, trn_labels, fs, step)
            index_selected_all.append(index_selected)
        importance = [[] for fs_ in num_fs]
        return index_selected_all, importance
    elif method == 'fdr':
        index_selected_all = []
        for fs in num_fs:
            _, index_selected, fdr = fdr_select_features(trn_feats, trn_labels, fs)
            index_selected_all.append(index_selected)
        importance = [fdr for fs_ in num_fs]
        return index_selected_all, importance
    elif method== 'ANOVA':
        index_selected_all = []
        for fs in num_fs:
            _, index_selected, importances = ANOVA_select_features(trn_feats, trn_labels, fs)
            index_selected_all.append(index_selected)
        importance = [importances for fs_ in num_fs]
        return index_selected_all, importance
    elif method == 'PeaCorr':
        index_selected_all = []
        for fs in num_fs:
            _, index_selected, importances = pearson_correlation_test(trn_feats, trn_labels, fs)
            index_selected_all.append(index_selected)
        importance = [importances for fs_ in num_fs]
        return index_selected_all, importance
    elif method == 'MutInfo':
        index_selected_all = []
        for fs in num_fs:
            _, index_selected, importances = mutual_info(trn_feats, trn_labels, fs)
            index_selected_all.append(index_selected)
        importance = [importances for fs_ in num_fs]
        return index_selected_all, importance
    elif method == 'mRMR':
        index_selected = mRMR_select_features(trn_feats, trn_labels)
        index_selected_all = [np.array(index_selected[0:fs_]) for fs_ in num_fs]
        importance = [[] for fs_ in num_fs]
        return index_selected_all, importance
    elif method == 'CCM':
        index_selected_all = []
        for fs in num_fs:
            index_selected = CCM_select_features(trn_feats, trn_labels, fs)
            index_selected_all.append(index_selected[0:fs])
        importance = [[] for fs_ in num_fs]
        return index_selected_all, importance
    elif method == 'DFS':
        index_selected, importances = deep_feature_selection(trn_feats, trn_labels, parameter, random_state)
        index_selected_all=[]
        for fs in num_fs:
            index_selected_all.append(index_selected[0:fs])
        importance = [importances for fs_ in num_fs]
        return index_selected_all, importance
    elif method == 'dropoutFR':
        index_selected, importances = dropoutFR_feature_selection(trn_feats, trn_labels, parameter, random_state)
        index_selected_all=[]
        for fs in num_fs:
            index_selected_all.append(index_selected[0:fs])
        importance = [importances for fs_ in num_fs]
        return index_selected_all, importance
    elif method == 'DeepFIR':
        importances = DeepFIR_feature_selection(trn_feats, trn_labels, parameter, random_state)
        index_selected = np.argsort(-importances)
        index_selected_all = []
        for fs in num_fs:
            index_selected_all.append(index_selected[0:fs])
        importance = [importances for fs_ in num_fs]
        return index_selected_all, importance
    elif method == 'DDR':
        importances = DDR_select_features(trn_feats, trn_labels, parameter, random_state)
        index_selected = np.argsort(-importances)
        index_selected_all = []
        for fs in num_fs:
            index_selected_all.append(index_selected[0:fs])
        importance = [importances for fs_ in num_fs]
        return index_selected_all, importance
    elif method == 'NetAct_FIR':
        importances = NetAct_FIR_select_features(trn_feats, trn_labels, parameter, random_state)
        index_selected = np.argsort(-importances)
        index_selected_all = []
        for fs in num_fs:
            index_selected_all.append(index_selected[0:fs])
        importance = [importances for fs_ in num_fs]
        return index_selected_all, importance
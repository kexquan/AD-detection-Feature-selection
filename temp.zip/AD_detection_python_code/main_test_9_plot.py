import pdb

import numpy as np

import seaborn as sns
import matplotlib.pyplot as plt

def plot_with_variance(reward_mean, reward_var, color='yellow', savefig_dir=None):
    """plot_with_variance
        reward_mean: typr list, containing all the means of reward summmary scalars collected during training
        reward_var: type list, containing all variance
        savefig_dir: if not None, this must be a str representing the directory to save the figure
    """
    lower = [x - y for x, y in zip(reward_mean, reward_var)]
    upper = [x + y for x, y in zip(reward_mean, reward_var)]
    plt.figure()
    xaxis = list(range(1, len(lower) + 1))
    plt.plot(xaxis, reward_mean, '--o', markersize=2.5, color=color)
    plt.fill_between(xaxis, lower, upper, color=color, alpha=0.2)
    # plt.grid()
    # plt.xlabel('Number of features in feature subset', fontsize=15)
    # plt.ylabel('Recognition accuracy', fontsize=15)
    # plt.xticks(fontsize=12)
    # plt.yticks(fontsize=12)
    # plt.tight_layout()
    # if savefig_dir is not None and type(savefig_dir) is str:
    #     plt.savefig(savefig_dir, format='jpg')
    # plt.show()


if __name__ == '__main__':

    datasetfold = "jccocc_2022_03_19"

    datas = ['jccocc_34', 'jccocc_35', 'jccocc_36', 'jccocc_37', 'jccocc_38', 'jccocc_39']

    random_states = list(range(5))

    accuracy_mean_all_methods = []
    accuracy_var_all_methods = []


    plot_range = np.array(range(9,2001,20))
    num_fs = plot_range + 1

    colors = ['r', 'b', 'y', 'g', 'm']

    legends = ['DFR', 'DFS', 'DropoutFR', 'DDR', 'RF', 'DeepFIR']


    for data in datas:

        acc_all_folds = np.load(data + '_random_states_' + ''.join([str(item) for item in random_states]) + '.npy')
        accuracy_mean_all_methods.append(np.mean(np.concatenate(acc_all_folds), axis=0)[plot_range])
        accuracy_var_all_methods.append(np.var(np.concatenate(acc_all_folds), axis=0)[plot_range])

        print(data)
        print('The number of selected features: ', num_fs[np.mean(np.concatenate(acc_all_folds), axis=0)[plot_range].argmax()])
        print('The highest recognition accuracy: %.3f ' % np.mean(np.concatenate(acc_all_folds), axis=0)[plot_range].max())
        print('The mean recognition accuracy: %.3f ' % np.mean(np.concatenate(acc_all_folds), axis=0)[plot_range].mean())

    fig, axes = plt.subplots(figsize=(4, 3), dpi=600)

    for i in range(len(accuracy_mean_all_methods)):
        # axes.plot(num_fs, acc, '--o', markersize=2)

        reward_mean = accuracy_mean_all_methods[i]
        reward_var = accuracy_var_all_methods[i]

        lower = [x - y for x, y in zip(reward_mean, reward_var)]
        upper = [x + y for x, y in zip(reward_mean, reward_var)]
        # axes.plot(num_fs, reward_mean, '--o', linewidth=0.65, markersize=1, color=colors[i])
        # axes.fill_between(num_fs, lower, upper, alpha=0.2, color=colors[i])

        axes.plot(num_fs, reward_mean, '--o', linewidth=0.5, markersize=1)
        axes.fill_between(num_fs, lower, upper, alpha=0.1)

    axes.set_xlabel('Number of features in feature subset', fontsize=10)
    axes.set_ylabel('Recognition accuracy', fontsize=10)
    labels = axes.get_xticklabels() + axes.get_yticklabels()
    [label.set_fontstyle('italic') for label in labels]

    axes.tick_params(axis='y', labelsize=10, color='k', labelcolor='k', direction='in')

    axes.tick_params(axis='x',labelsize=10,color='k',labelcolor='k',direction='in')
    plt.savefig(data + '_random_states_' + ''.join([str(item) for item in random_states]) + '.jpg')
    plt.grid()
    plt.tight_layout()
    plt.legend(legends)
    plt.savefig('cross_val_all_methods.pdf')
    plt.show()
    # print('The number of selected features: ', np.mean(np.concatenate(acc_all_folds), axis=0).argmax() + 1)
    # print('The highest recognition accuracy: ', np.mean(np.concatenate(acc_all_folds), axis=0).max())